"""TM-DRO snapshot benchmark under combined mismatch.

Run: python TM_DRO_Snapshot_Loss_Gap.py
The default run produces separate loss-gap figures at 0, 5, and 10 dB.
Dependencies: PyTorch, CVXPY with SCS, NumPy, and Matplotlib.

The scene generator, learned models, optimizers, and baseline implementations
are adapted from TM_DRO_Q4Q5_normfix_fair_warmup.py.
"""

import argparse
import csv
import hashlib
import json
import math
import os
import pickle
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Dict, List, Optional, Tuple

try:
    import cvxpy as cp
    import matplotlib as mpl
    import numpy as np
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except ImportError as error:
    raise SystemExit(
        f"Missing dependency: {error.name}. "
        "Run in the original benchmark environment or install torch, cvxpy, scs, numpy, and matplotlib."
    ) from error

mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator, NullLocator



def set_pub_style():
    """
    Print-ready style:
      - Times-like font
      - strong but non-intrusive grid (major/minor)
      - ticks/spines visible after downscaling
      - PDF embeds TrueType fonts (fonttype 42)
    """
    mpl.rcParams.update({
        # ---- Fonts ----
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "Nimbus Roman", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "axes.unicode_minus": False,

        # ---- Save settings ----
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,

        # ---- Sizes (paper-like) ----
        "axes.labelsize": 10,
        "axes.titlesize": 10,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 8,

        # ---- Lines ----
        "lines.linewidth": 2.0,
        "lines.markersize": 5.2,

        # ---- Axes ----
        "axes.linewidth": 1.0,
        "axes.grid": False,  # we control grid per-axis for major/minor
        "axes.spines.top": False,
        "axes.spines.right": False,

        # ---- Ticks ----
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.size": 4.0,
        "ytick.major.size": 4.0,
        "xtick.major.width": 1.0,
        "ytick.major.width": 1.0,
        "xtick.minor.size": 2.5,
        "ytick.minor.size": 2.5,
        "xtick.minor.width": 0.9,
        "ytick.minor.width": 0.9,
    })


def apply_axis_style(ax: plt.Axes):
    """
    Ensure grid and tick appearance are 'journal visible' after downscale/print.
    """
    # Minor ticks
    ax.xaxis.set_minor_locator(AutoMinorLocator(2) if ax.get_xscale() == "linear" else NullLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))

    # Major grid (visible, not too dark)
    ax.grid(True, which="major", linestyle="-", linewidth=0.8, alpha=0.35)

    # Minor grid (lighter)
    ax.grid(True, which="minor", linestyle="--", linewidth=0.6, alpha=0.22)

    # Spines a bit stronger
    for side in ["left", "bottom"]:
        ax.spines[side].set_linewidth(1.0)

    # Keep ticks crisp
    ax.tick_params(which="both", top=False, right=False)


def savefig_dual(path_base: str, dpi: int = 450):
    """
    Save both PDF (vector) and PNG (high-dpi raster preview).
    """
    plt.savefig(path_base + ".pdf")
    plt.savefig(path_base + ".png", dpi=dpi)


def set_seed(seed: int = 0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def cplx_eye(n: int, device, dtype=torch.complex64):
    return torch.eye(n, device=device, dtype=dtype)


def hermitize(R: torch.Tensor) -> torch.Tensor:
    return 0.5 * (R + torch.conj(R.transpose(-1, -2)))


def steering_ula(N: int, d_over_lambda: float, theta_deg: torch.Tensor, device, dtype=torch.complex64) -> torch.Tensor:
    """
    ULA steering: a_n = exp(j*2*pi*d/lambda*n*sin(theta)), normalized to ||a||2=1
    theta_deg: [B]
    return: [B, N]
    """
    theta = theta_deg * math.pi / 180.0
    n = torch.arange(N, device=device, dtype=torch.float32)[None, :]
    phase = 2.0 * math.pi * d_over_lambda * n * torch.sin(theta)[:, None]
    a = torch.exp(1j * phase.to(torch.complex64))
    a = a / torch.linalg.norm(a, dim=-1, keepdim=True).clamp_min(1e-12)
    return a.to(dtype)


def solve(A: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    return torch.linalg.solve(A, b.unsqueeze(-1)).squeeze(-1)


def abs2(x: torch.Tensor) -> torch.Tensor:
    return (x.real * x.real + x.imag * x.imag)


def safe_log(x: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    return torch.log(x.clamp_min(eps))


def trace_batch(R: torch.Tensor) -> torch.Tensor:
    return R.diagonal(dim1=-2, dim2=-1).sum(-1)


def quad_form(w: torch.Tensor, R: torch.Tensor) -> torch.Tensor:
    v = (torch.conj(w).unsqueeze(1) @ (R @ w.unsqueeze(-1))).squeeze(-1).squeeze(-1)
    return v.real


@dataclass
class SimCfg:
    N: int = 10
    d_over_lambda: float = 0.5
    theta_s_nom_deg: float = -5.0
    mismatch_std_deg: float = 2.0
    theta_js_deg: Tuple[float, float, float] = (20.0, 50.0, 65.0)
    INR_dB: float = 20.0
    noise_var: float = 1.0
    a_samples_M: int = 16


def sample_complex_gaussian(shape, device, dtype=torch.complex64):
    x = torch.randn(*shape, device=device, dtype=torch.float32)
    y = torch.randn(*shape, device=device, dtype=torch.float32)
    z = (x + 1j * y) / math.sqrt(2.0)
    return z.to(dtype)


def gen_scene_batch(cfg: SimCfg, B: int, L: int, snr_db: torch.Tensor, device) -> Dict[str, torch.Tensor]:
    """
    Generates:
      Rhat: sample covariance
      Rin_true: true interference+noise covariance (no desired signal)
      a_true: desired steering with mismatch
      a_nom: nominal desired steering
      bar_a: averaged steering samples
      A_j: interferer steering stack [B,N,3]
      sigma_s2: desired power (linear)
    """
    N = cfg.N
    dtype = torch.complex64

    snr_lin = (10.0 ** (snr_db / 10.0)).to(torch.float32)
    sigma_s2 = snr_lin * cfg.noise_var
    sigma_s = torch.sqrt(sigma_s2).to(torch.float32)

    theta_s_true = (
        torch.tensor(cfg.theta_s_nom_deg, device=device, dtype=torch.float32)
        + torch.randn(B, device=device, dtype=torch.float32) * cfg.mismatch_std_deg
    )
    a_true = steering_ula(N, cfg.d_over_lambda, theta_s_true, device, dtype=dtype)

    theta_s_nom = torch.full((B,), float(cfg.theta_s_nom_deg), device=device, dtype=torch.float32)
    a_nom = steering_ula(N, cfg.d_over_lambda, theta_s_nom, device, dtype=dtype)

    inr_lin = 10.0 ** (cfg.INR_dB / 10.0)
    sigma_i2 = inr_lin * cfg.noise_var

    theta_j = [torch.full((B,), float(th), device=device, dtype=torch.float32) for th in cfg.theta_js_deg]
    a_j = [steering_ula(N, cfg.d_over_lambda, th, device, dtype=dtype) for th in theta_j]
    A_j = torch.stack(a_j, dim=-1)  # [B,N,3]

    I = cplx_eye(N, device, dtype=dtype).unsqueeze(0).expand(B, -1, -1)
    Rin_true = cfg.noise_var * I
    for aj in a_j:
        Rin_true = Rin_true + sigma_i2 * (aj[:, :, None] * torch.conj(aj[:, None, :]))
    Rin_true = hermitize(Rin_true)

    s = sample_complex_gaussian((B, L), device, dtype=dtype) * sigma_s[:, None].to(dtype)
    u = [sample_complex_gaussian((B, L), device, dtype=dtype) * math.sqrt(sigma_i2) for _ in range(3)]
    n = sample_complex_gaussian((B, N, L), device, dtype=dtype) * math.sqrt(cfg.noise_var)

    X = a_true[:, :, None] * s[:, None, :]
    for aj, uj in zip(a_j, u):
        X = X + aj[:, :, None] * uj[:, None, :]
    X = X + n

    Rhat = (X @ torch.conj(X.transpose(-1, -2))) / float(L)
    Rhat = hermitize(Rhat)

    M = cfg.a_samples_M
    theta_samples = (
        torch.tensor(cfg.theta_s_nom_deg, device=device, dtype=torch.float32)[None, None]
        + torch.randn(B, M, device=device, dtype=torch.float32) * cfg.mismatch_std_deg
    )
    a_samps = steering_ula(N, cfg.d_over_lambda, theta_samples.reshape(-1), device, dtype=dtype).reshape(B, M, N)
    bar_a = a_samps.mean(dim=1)
    bar_a = bar_a / torch.linalg.norm(bar_a, dim=-1, keepdim=True).clamp_min(1e-12)

    return {
        "Rhat": Rhat,
        "Rin_true": Rin_true,
        "a_true": a_true,
        "a_nom": a_nom,
        "bar_a": bar_a,
        "A_j": A_j,
        "sigma_s2": sigma_s2.to(torch.float32),
    }


class SSMBlock(nn.Module):
    def __init__(self, d_model: int, kernel_size: int = 7, expansion: int = 2, dropout: float = 0.0):
        super().__init__()
        self.ln = nn.LayerNorm(d_model)
        self.dw = nn.Conv1d(d_model, d_model, kernel_size=kernel_size,
                            padding=kernel_size // 2, groups=d_model)
        self.pw1 = nn.Linear(d_model, d_model * expansion * 2)
        self.pw2 = nn.Linear(d_model * expansion, d_model)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.ln(x)
        h = h + self.dw(h.transpose(1, 2)).transpose(1, 2)
        u = self.pw1(h)
        a, b = u.chunk(2, dim=-1)
        h = F.silu(a) * torch.sigmoid(b)
        h = self.pw2(h)
        h = self.drop(h)
        return x + h


def eig_tokens(Rhat: torch.Tensor) -> torch.Tensor:
    """Tokens [B,N,3] = [log_e, log_ratio, idx]."""
    B, N, _ = Rhat.shape
    evals = torch.linalg.eigvalsh(Rhat).real
    evals = torch.flip(evals, dims=[-1])
    log_e = safe_log(evals + 1e-8)
    log_ratio = log_e - safe_log(evals.sum(dim=-1, keepdim=True) + 1e-8)
    idx = (torch.arange(N, device=Rhat.device, dtype=torch.float32)[None, :] / max(1, N - 1)).expand(B, -1)
    return torch.stack([log_e, log_ratio, idx], dim=-1)


class EigenTokenSSM(nn.Module):
    """Full proposed: token mixing -> tau,rho,lam_diag + embed."""
    def __init__(self, N: int, d_model: int = 96, n_layers: int = 3, dropout: float = 0.05):
        super().__init__()
        self.N = N
        self.proj = nn.Linear(3, d_model)
        self.blocks = nn.ModuleList([SSMBlock(d_model, 7, 2, dropout) for _ in range(n_layers)])
        self.ln_out = nn.LayerNorm(d_model)

        self.head_tau = nn.Sequential(nn.Linear(d_model, d_model // 2), nn.SiLU(), nn.Linear(d_model // 2, 1))
        self.head_rho = nn.Sequential(nn.Linear(d_model, d_model // 2), nn.SiLU(), nn.Linear(d_model // 2, 1))
        self.head_lam = nn.Sequential(nn.Linear(d_model, d_model), nn.SiLU(), nn.Linear(d_model, N))

        self.tau_scale = 2.0
        self.rho_scale = 0.5

    def forward(self, Rhat: torch.Tensor) -> Dict[str, torch.Tensor]:
        tok = eig_tokens(Rhat)
        x = self.proj(tok)
        for blk in self.blocks:
            x = blk(x)
        x = self.ln_out(x)
        g = x.mean(dim=1)

        tau = F.softplus(self.head_tau(g)).squeeze(-1) * self.tau_scale + 1e-6
        rho = F.softplus(self.head_rho(g)).squeeze(-1) * self.rho_scale + 1e-6
        lam = F.softplus(self.head_lam(g)) + 1e-4
        return {"tau": tau, "rho": rho, "lam_diag": lam, "embed": g}


class CVCNNBeamformer(nn.Module):
    """CVCNN baseline from Mohammadzadeh et al. (2022 SPL).
    1D Conv on flattened SCM (real + imag stacked as channels) -> complex weights.
    End-to-end trained to maximize SINR (consistent with other data-driven baselines).
    """
    def __init__(self, N: int = 10):
        super().__init__()
        self.N = N
        input_len = N * N                     # full SCM vectorized

        # Real-valued 1D Conv on [real, imag] channels (practical approximation of complex conv)
        self.conv1 = nn.Conv1d(2, 64, kernel_size=5, padding=2)
        self.conv2 = nn.Conv1d(64, 128, kernel_size=5, padding=2)
        self.conv3 = nn.Conv1d(128, 256, kernel_size=3, padding=1)
        self.conv4 = nn.Conv1d(256, 256, kernel_size=3, padding=1)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.fc1 = nn.Linear(256, 512)
        self.fc2 = nn.Linear(512, 2 * N)      # real + imag of w

        self.dropout = nn.Dropout(0.25)

    def forward(self, Rhat: torch.Tensor, a_nom: torch.Tensor = None) -> torch.Tensor:
        B, N, _ = Rhat.shape
        # Flatten Hermitian matrix -> complex vector [B, N*N]
        r_flat = Rhat.reshape(B, -1)                     # complex

        # Stack real/imag as 2 channels -> [B, 2, input_len]
        x = torch.stack([r_flat.real, r_flat.imag], dim=1)

        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.max_pool1d(x, kernel_size=2, stride=2)
        x = F.relu(self.conv3(x))
        x = F.relu(self.conv4(x))

        x = self.pool(x).squeeze(-1)                     # [B, 256]
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        y = self.fc2(x)

        w = torch.complex(y[:, :N], y[:, N:])

        # Distortionless constraint w.r.t. nominal steering vector (like MVDR)
        if a_nom is not None:
            denom = (torch.conj(w) * a_nom).sum(dim=-1).real.clamp_min(1e-8)
            w = w / denom.unsqueeze(-1)

        return w


@torch.no_grad()
def irani_dro_weight(
    Rhat: torch.Tensor,
    a_nom: torch.Tensor,
    rho1: float = None,
    rho2: float = None,
    gamma1: float = None,
    gamma2: float = 0.1,
    Delta: float = 0.1,
    alpha: float = 1e3,
    eta: float = 1e-6,
    max_iter: int = 50,
    fallback_indices: Optional[List[int]] = None,
) -> torch.Tensor:
    """
    Irani et al. (IEEE TSP 2025) - SINR Maximizing Distributionally Robust Adaptive Beamforming
    Fully fixed:
      - M2 / M2_pen scalar blocks now use explicit (1,1) arrays
      - All inequality constraints are explicitly real-valued via cp.real(...)
    """
    device = Rhat.device
    dtype = torch.complex64
    B, N, _ = Rhat.shape

    # Default parameters (paper-consistent)
    S0_np = Rhat[0].cpu().numpy().astype(np.complex128)
    a0_np = a_nom[0].cpu().numpy().astype(np.complex128)

    if rho1 is None:
        rho1 = 0.001 * np.linalg.norm(S0_np, 'fro')
    if rho2 is None:
        rho2 = 1.1 * np.trace(S0_np).real
    if gamma1 is None:
        gamma1 = 0.01 * np.linalg.norm(a0_np)

    w_list = []
    for b in range(B):
        S0 = Rhat[b].cpu().numpy().astype(np.complex128)
        a0 = a_nom[b].cpu().numpy().astype(np.complex128)

        # ============== Variables ==============
        W = cp.Variable((N, N), hermitian=True)
        X = cp.Variable((N, N), hermitian=True)
        Z = cp.Variable((N, N), hermitian=True)
        x = cp.Variable(N, complex=True)
        tau1 = cp.Variable(1, nonneg=False)
        tau2 = cp.Variable(1, nonneg=False)

        # ============== Objective ==============
        obj = rho1 * cp.norm(X, 'fro') + rho2 * cp.norm(W + X, 'fro') - cp.real(cp.trace(X @ S0))

        # ============== Constraints (main) ==============
        constraints = []
        # steering vector dual constraint (real-valued)
        real_part = cp.real(x.conj().T @ a0) - gamma1 * cp.norm(x)
        constraints.append(
            real_part - cp.real(
                cp.trace(Z @ ((1 + gamma2) * np.eye(N) + np.outer(a0, a0.conj())))
            ) >= 1
        )

        # LMI for support set Z2 (Eq.33 + Eq.34)
        I = np.eye(N, dtype=np.complex128)
        M1 = cp.bmat([
            [W + Z, -cp.reshape(x, (N, 1), order="F")],
            [-cp.reshape(cp.conj(x), (1, N), order="F"),
             cp.reshape(-(1 + Delta) * N, (1, 1), order="F")]
        ])
        M2 = cp.bmat([                                      # FIXED: scalar → (1,1) array
            [-I, np.zeros((N, 1))],
            [np.zeros((1, N)), np.array([[float((1 - Delta) * N)]])]
        ])
        constraints.append(M1 >> tau1 * M2 + tau2 * (-M2))
        constraints.append(tau1 <= 0)
        constraints.append(tau2 <= 0)

        constraints += [W >> 0, Z >> 0, X >> 0]

        prob = cp.Problem(cp.Minimize(obj), constraints)
        try:
            prob.solve(solver=cp.SCS, verbose=False)
            W_star = W.value
            if W_star is None or not np.all(np.isfinite(W_star)):
                raise RuntimeError("Irani DRO returned an invalid matrix")
        except (cp.error.SolverError, ValueError, RuntimeError):
            if fallback_indices is not None:
                fallback_indices.append(b)
            w = mvdr_weight(Rhat[b:b+1], a_nom[b:b+1])[0]
            w_list.append(w.cpu().numpy())
            continue

        # ============== Algorithm 1: rank-1 extraction (penalty) ==============
        if np.abs(np.trace(W_star) - np.linalg.norm(W_star, 'fro')) < 1e-5:
            w = np.linalg.eigh(W_star)[1][:, -1]
        else:
            Wk = W_star.copy()
            for it in range(max_iter):
                W_var = cp.Variable((N, N), hermitian=True)
                X_var = cp.Variable((N, N), hermitian=True)
                Z_var = cp.Variable((N, N), hermitian=True)
                x_var = cp.Variable(N, complex=True)
                tau1_var = cp.Variable(1, nonneg=False)
                tau2_var = cp.Variable(1, nonneg=False)

                obj_pen = (rho1 * cp.norm(X_var, 'fro') +
                           rho2 * cp.norm(W_var + X_var, 'fro') -
                           cp.real(cp.trace(X_var @ S0)) +
                           alpha * (cp.real(cp.trace(W_var)) -
                                    cp.real(cp.trace(W_var @ Wk)) / np.linalg.norm(Wk, 'fro')))

                # FIXED: explicitly real-valued inequality
                cons_pen = [
                    cp.real(x_var.conj().T @ a0) - gamma1 * cp.norm(x_var) -
                    cp.real(cp.trace(Z_var @ ((1 + gamma2) * np.eye(N) + np.outer(a0, a0.conj())))) >= 1
                ]

                M1_pen = cp.bmat([
                    [W_var + Z_var, -cp.reshape(x_var, (N, 1), order="F")],
                    [-cp.reshape(cp.conj(x_var), (1, N), order="F"),
                     cp.reshape(-(1 + Delta) * N, (1, 1), order="F")]
                ])
                M2_pen = cp.bmat([                          # FIXED: scalar → (1,1) array
                    [-np.eye(N), np.zeros((N, 1))],
                    [np.zeros((1, N)), np.array([[float((1 - Delta) * N)]])]
                ])
                cons_pen.append(M1_pen >> tau1_var * M2_pen + tau2_var * (-M2_pen))
                cons_pen += [tau1_var <= 0, tau2_var <= 0]
                cons_pen += [W_var >> 0, Z_var >> 0, X_var >> 0]

                prob_pen = cp.Problem(cp.Minimize(obj_pen), cons_pen)
                prob_pen.solve(solver=cp.SCS, verbose=False)

                W_next = W_var.value
                if W_next is None or not np.all(np.isfinite(W_next)):
                    break
                if np.abs(np.trace(W_next) - np.linalg.norm(W_next, 'fro')) < eta:
                    Wk = W_next
                    break
                Wk = W_next

            eigvals, eigvecs = np.linalg.eigh(Wk)
            w = eigvecs[:, -1]

        # distortionless normalization
        denominator = w.conj().T @ a0
        if not np.isfinite(denominator) or abs(denominator) < 1e-10:
            if fallback_indices is not None:
                fallback_indices.append(b)
            w = mvdr_weight(Rhat[b:b+1], a_nom[b:b+1])[0].cpu().numpy()
        else:
            w = w / denominator
        w_list.append(w)

    w_torch = torch.tensor(np.stack(w_list), dtype=torch.complex64, device=device)
    return w_torch


def mvdr_weight(R: torch.Tensor, a: torch.Tensor) -> torch.Tensor:
    """
    MVDR: w = R^{-1} a / (a^H R^{-1} a)
    """
    x = solve(R, a)  # R^{-1} a
    denom = (torch.conj(a) * x).sum(dim=-1)  # complex, should be ~real
    denom_real = denom.real.clamp_min(1e-12)
    return x / denom_real.unsqueeze(-1).to(x.dtype)


def lsmi_weight(Rhat: torch.Tensor, a: torch.Tensor, beta: float = 0.1) -> torch.Tensor:
    B, N, _ = Rhat.shape
    I = cplx_eye(N, Rhat.device, dtype=Rhat.dtype)[None].expand(B, -1, -1)
    tr = trace_batch(Rhat).real
    delta = beta * (tr / float(N)).to(torch.float32)
    Rl = Rhat + delta[:, None, None].to(Rhat.dtype) * I
    return mvdr_weight(Rl, a)


@torch.no_grad()
def wc_qmi_a1_lmi_weight(
    Rhat: torch.Tensor,
    a_nom: torch.Tensor,
    delta_frac: float = 0.30,
    eta1_frac: float = 0.20,
    eta2_frac: float = 0.20,
    cov_dl_rel: float = 0.10,
    solver: str = "SCS",
    verbose: bool = False,
    max_iters: int = 500,
    eps: float = 1e-3,
    fallback_indices: Optional[List[int]] = None,
) -> torch.Tensor:
    """
    Worst-case SINR with nonconvex steering uncertainty set A1:
        ||a-a_hat||^2 <= Delta,
        norm2-eta1 <= ||a||^2 <= norm2+eta2.

    This implements the tightened LMI relaxation of the QMI-A1 formulation.
    It extracts the principal rank-one approximation if W is not numerically rank-one.

    Important:
       steering vectors are normalized to ||a||=1, while the paper often uses
      ||a||^2=N. Therefore Delta/eta are scaled by norm2 = ||a_nom||^2.
    """
    B, N, _ = Rhat.shape
    device = Rhat.device
    dtype = torch.complex64

    w_list = []

    for b in range(B):
        R_np = hermitize(Rhat[b]).detach().cpu().numpy().astype(np.complex128)
        a_np = a_nom[b].detach().cpu().numpy().astype(np.complex128)

        norm2 = float(np.vdot(a_np, a_np).real)
        Delta = float(delta_frac * norm2)
        eta1 = float(eta1_frac * norm2)
        eta2 = float(eta2_frac * norm2)

        # covariance uncertainty loading: R_hat in the paper can include sqrt(gamma) I
        lam_min = max(float(np.linalg.eigvalsh(R_np).min().real), 1e-8)
        R_np = R_np + (cov_dl_rel * lam_min) * np.eye(N, dtype=np.complex128)
        R_np = 0.5 * (R_np + R_np.conj().T)

        W = cp.Variable((N, N), hermitian=True)
        y1 = cp.Variable()
        y2 = cp.Variable()
        y3 = cp.Variable()
        y4 = cp.Variable()

        top_left = W - (y1 + y2 + y3) * np.eye(N)
        top_right = cp.reshape(y1 * a_np, (N, 1), order="F")
        bottom_left = cp.reshape(y1 * a_np.conj(), (1, N), order="F")
        bottom_right = cp.reshape(
            -y4 - y1 * (norm2 - Delta), (1, 1), order="F"
        )

        Q = cp.bmat([
            [top_left, top_right],
            [bottom_left, bottom_right],
        ])

        constraints = [
            (norm2 - eta1) * y2 + (norm2 + eta2) * y3 + y4 == 1,
            Q >> 0,
            W >> 0,
            y1 <= 0,
            y2 >= 0,
            y3 <= 0,
            y1 + y2 + y3 <= 0,   # tightened valid linear constraint
        ]

        obj = cp.Minimize(cp.real(cp.trace(R_np @ W)))
        prob = cp.Problem(obj, constraints)

        try:
            prob.solve(
                solver=solver,
                verbose=verbose,
                max_iters=max_iters,
                eps=eps,
                warm_start=True,
            )
            Wv = W.value
            if Wv is None or not np.all(np.isfinite(Wv)):
                raise RuntimeError("WC-QMI solver returned invalid W")

            Wv = 0.5 * (Wv + Wv.conj().T)
            vals, vecs = np.linalg.eigh(Wv)
            idx = int(np.argmax(vals.real))
            val = max(float(vals[idx].real), 1e-12)
            w = np.sqrt(val) * vecs[:, idx]

            # distortionless normalization
            den = np.vdot(w, a_np)
            if abs(den) < 1e-10:
                raise RuntimeError("WC-QMI normalization failed")
            w = w / den.conj()

        except (cp.error.SolverError, ValueError, RuntimeError, np.linalg.LinAlgError):
            # stable fallback: do not crash Monte Carlo
            if fallback_indices is not None:
                fallback_indices.append(b)
            R_t = torch.tensor(R_np[None], device=device, dtype=dtype)
            a_t = torch.tensor(a_np[None], device=device, dtype=dtype)
            w = mvdr_weight(R_t, a_t)[0].detach().cpu().numpy()

        w_list.append(w.astype(np.complex64))

    return torch.tensor(np.stack(w_list), device=device, dtype=dtype)


def sinr_out_db(w, a_true, Rin_true, sigma_s2) -> torch.Tensor:
    num = sigma_s2 * abs2((torch.conj(w) * a_true).sum(dim=-1))
    den = quad_form(w, Rin_true).clamp_min(1e-12)
    sinr = (num / den).clamp_min(1e-12)
    return 10.0 * torch.log10(sinr)


def train_model(model: nn.Module, cfg: SimCfg, device,
                epochs: int, steps_per_epoch: int, batch_size: int,
                L_choices: Tuple[int, ...], snr_range: Tuple[float, float],
                lr: float = 3e-4) -> Dict[str, List[float]]:
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    hist = {"train": [], "val": []}

    def val_step(num_batches: int = 20) -> float:
        model.eval()
        vals = []
        with torch.no_grad():
            for _ in range(num_batches):
                L = random.choice(L_choices)
                snr = snr_range[0] + (snr_range[1] - snr_range[0]) * torch.rand(batch_size, device=device)
                batch = gen_scene_batch(cfg, batch_size, L, snr, device)
                out = model(batch["Rhat"])
                w = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out["tau"], out["rho"], out["lam_diag"])
                sinr = sinr_out_db(w, batch["a_true"], batch["Rin_true"], batch["sigma_s2"])
                vals.append((-sinr.mean()).item())
        model.train()
        return float(np.mean(vals))

    for ep in range(1, epochs + 1):
        losses = []
        for _ in range(steps_per_epoch):
            L = random.choice(L_choices)
            snr = snr_range[0] + (snr_range[1] - snr_range[0]) * torch.rand(batch_size, device=device)
            batch = gen_scene_batch(cfg, batch_size, L, snr, device)

            out = model(batch["Rhat"])
            w = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out["tau"], out["rho"], out["lam_diag"])
            sinr = sinr_out_db(w, batch["a_true"], batch["Rin_true"], batch["sigma_s2"])
            loss_main = -sinr.mean()

            reg = 1e-4 * (out["rho"] ** 2).mean() + 1e-4 * (out["tau"] ** 2).mean()
            reg = reg + 1e-5 * (safe_log(out["lam_diag"]) ** 2).mean()
            loss = loss_main + reg

            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            losses.append(loss_main.item())

        v = val_step()
        hist["train"].append(float(np.mean(losses)))
        hist["val"].append(v)
        print(f"Epoch {ep:03d}/{epochs} | train(-mean SINR dB)={hist['train'][-1]:.3f} | val={v:.3f}")

    return hist


def robust_beamformer_from_params(Rhat, bar_a, tau, rho, lam_diag, eps_max: float = 0.25) -> torch.Tensor:
    """
    Revised robust mapping.

    Why this replacement is necessary:
    The old mapping used w = alpha * v, where tau and Lambda mainly changed alpha.
    Output SINR is scale-invariant to alpha, so tau and Lambda had almost no effect on SINR.
    Here tau and Lambda perturb the robust steering vector itself:
        R_rho = Rhat + rho I
        v = R_rho^{-1} bar_a
        d = normalize(v / sqrt(lambda))
        a_rob = normalize(bar_a - eta(tau) d)
        w = MVDR(R_rho, a_rob)

    Therefore tau and Lambda affect the beampattern and the output SINR.
    """
    B, N, _ = Rhat.shape
    dtype = Rhat.dtype
    I = cplx_eye(N, Rhat.device, dtype=dtype)[None].expand(B, -1, -1)

    Rrho = Rhat + rho[:, None, None].to(dtype) * I
    v = solve(Rrho, bar_a)

    d = v / torch.sqrt(lam_diag.clamp_min(1e-6)).to(dtype)
    d = d / torch.linalg.norm(d, dim=-1, keepdim=True).clamp_min(1e-12)

    eta = eps_max * (tau / (1.0 + tau)).clamp(0.0, 1.0)
    a_rob = bar_a - eta[:, None].to(dtype) * d
    a_rob = a_rob / torch.linalg.norm(a_rob, dim=-1, keepdim=True).clamp_min(1e-12)

    return mvdr_weight(Rrho, a_rob)


def array_positions_2d(N: int, d_over_lambda: float, array_type: str, device) -> torch.Tensor:
    """
    Return 2D sensor positions in wavelength units, shape [N, 2].
    array_type: "ula", "uca", or "ccaa".
    """
    array_type = array_type.lower()

    if array_type == "ula":
        x = (torch.arange(N, device=device, dtype=torch.float32) - (N - 1) / 2.0) * d_over_lambda
        y = torch.zeros_like(x)
        return torch.stack([x, y], dim=-1)

    if array_type == "uca":
        radius = max(d_over_lambda, N * d_over_lambda / (2.0 * math.pi))
        phi = 2.0 * math.pi * torch.arange(N, device=device, dtype=torch.float32) / N
        x = radius * torch.cos(phi)
        y = radius * torch.sin(phi)
        return torch.stack([x, y], dim=-1)

    if array_type == "ccaa":
        # Simple concentric circular antenna array: inner ring + outer ring.
        n1 = N // 2
        n2 = N - n1
        r1 = max(d_over_lambda, n1 * d_over_lambda / (2.0 * math.pi))
        r2 = 1.8 * r1

        phi1 = 2.0 * math.pi * torch.arange(n1, device=device, dtype=torch.float32) / max(1, n1)
        phi2 = 2.0 * math.pi * (torch.arange(n2, device=device, dtype=torch.float32) + 0.5) / max(1, n2)

        p1 = torch.stack([r1 * torch.cos(phi1), r1 * torch.sin(phi1)], dim=-1)
        p2 = torch.stack([r2 * torch.cos(phi2), r2 * torch.sin(phi2)], dim=-1)
        return torch.cat([p1, p2], dim=0)

    raise ValueError("array_type must be 'ula', 'uca', or 'ccaa'.")


def steering_from_positions(pos: torch.Tensor, theta_deg: torch.Tensor, device, dtype=torch.complex64) -> torch.Tensor:
    """
    Far-field steering vector from 2D positions.
    theta is measured from the broadside of the ULA.
    pos: [N, 2]
    theta_deg: [B]
    return: [B, N]
    """
    theta = theta_deg.to(device=device, dtype=torch.float32) * math.pi / 180.0
    ux = torch.sin(theta)[:, None]
    uy = torch.cos(theta)[:, None]

    phase = 2.0 * math.pi * (ux * pos[None, :, 0] + uy * pos[None, :, 1])
    a = torch.exp(1j * phase.to(torch.complex64))
    a = a / torch.linalg.norm(a, dim=-1, keepdim=True).clamp_min(1e-12)
    return a.to(dtype)


def steering_from_batch_positions(pos_b: torch.Tensor, theta_deg: torch.Tensor, dtype=torch.complex64) -> torch.Tensor:
    """
    Batch-specific positions.
    pos_b: [B, N, 2]
    theta_deg: [B]
    return: [B, N]
    """
    theta = theta_deg.to(device=pos_b.device, dtype=torch.float32) * math.pi / 180.0
    ux = torch.sin(theta)[:, None]
    uy = torch.cos(theta)[:, None]

    phase = 2.0 * math.pi * (ux * pos_b[:, :, 0] + uy * pos_b[:, :, 1])
    a = torch.exp(1j * phase.to(torch.complex64))
    a = a / torch.linalg.norm(a, dim=-1, keepdim=True).clamp_min(1e-12)
    return a.to(dtype)


def normalize_complex_vec(a: torch.Tensor) -> torch.Tensor:
    return a / torch.linalg.norm(a, dim=-1, keepdim=True).clamp_min(1e-12)


def apply_gain_phase_error(a: torch.Tensor, amp: torch.Tensor, phase: torch.Tensor) -> torch.Tensor:
    """
    a: [B,N] or [B,N,K]
    amp, phase: [B,N]
    """
    g = amp * torch.exp(1j * phase.to(torch.complex64))
    if a.ndim == 2:
        out = a * g
        return out / torch.linalg.norm(out, dim=1, keepdim=True).clamp_min(1e-12)
    if a.ndim == 3:
        out = a * g[:, :, None]
        return out / torch.linalg.norm(out, dim=1, keepdim=True).clamp_min(1e-12)
    raise ValueError(f"Expected a with shape [B,N] or [B,N,K], got {tuple(a.shape)}")


def add_random_sv_error(a: torch.Tensor, eps: float) -> torch.Tensor:
    z = sample_complex_gaussian(a.shape, a.device, dtype=a.dtype)
    z = z / torch.linalg.norm(z, dim=-1, keepdim=True).clamp_min(1e-12)
    return normalize_complex_vec(a + eps * z)


@torch.no_grad()
def gen_scene_batch_revision(
    cfg: SimCfg,
    B: int,
    L: int,
    snr_db,
    device,
    array_type: str = "ula",
    error_type: str = "angle",
    gain_amp_std: float = 0.08,
    gain_phase_std_deg: float = 6.0,
    pos_std_lambda: float = 0.03,
    rand_sv_eps: float = 0.08,
    return_snapshots: bool = False,
) -> Dict[str, torch.Tensor]:
    """
    error_type:
      - "angle": DOA mismatch only
      - "gain_phase": element gain/phase error
      - "position": sensor position error
      - "random_sv": random steering-vector perturbation
      - "combined": all above
      - "none": no mismatch
    """
    N = cfg.N
    dtype = torch.complex64

    if not torch.is_tensor(snr_db):
        snr_db = torch.full((B,), float(snr_db), device=device, dtype=torch.float32)
    else:
        snr_db = snr_db.to(device=device, dtype=torch.float32)
        if snr_db.numel() == 1:
            snr_db = snr_db.expand(B)

    pos_nom = array_positions_2d(N, cfg.d_over_lambda, array_type, device)
    pos_true = pos_nom[None, :, :].expand(B, -1, -1).clone()

    if error_type in ["position", "combined"]:
        pos_true = pos_true + pos_std_lambda * torch.randn(B, N, 2, device=device)

    theta_nom = torch.full((B,), float(cfg.theta_s_nom_deg), device=device, dtype=torch.float32)
    theta_true = theta_nom.clone()

    if error_type in ["angle", "combined"]:
        theta_true = theta_true + cfg.mismatch_std_deg * torch.randn(B, device=device)

    a_nom = steering_from_positions(pos_nom, theta_nom, device, dtype=dtype)
    a_true = steering_from_batch_positions(pos_true, theta_true, dtype=dtype)

    a_j_list = []
    for th in cfg.theta_js_deg:
        th_vec = torch.full((B,), float(th), device=device, dtype=torch.float32)
        a_j_list.append(steering_from_batch_positions(pos_true, th_vec, dtype=dtype))
    A_j = torch.stack(a_j_list, dim=-1)

    if error_type in ["gain_phase", "combined"]:
        amp = 1.0 + gain_amp_std * torch.randn(B, N, device=device)
        phase = (gain_phase_std_deg * math.pi / 180.0) * torch.randn(B, N, device=device)
        a_true = apply_gain_phase_error(a_true, amp, phase)
        A_j = apply_gain_phase_error(A_j, amp, phase)

    if error_type in ["random_sv", "combined"]:
        a_true = add_random_sv_error(a_true, rand_sv_eps)

    # bar_a is still obtained from nominal uncertainty samples.
    M = cfg.a_samples_M
    theta_samples = (
        torch.tensor(cfg.theta_s_nom_deg, device=device, dtype=torch.float32)[None, None]
        + torch.randn(B, M, device=device, dtype=torch.float32) * cfg.mismatch_std_deg
    )
    a_samps = steering_from_positions(pos_nom, theta_samples.reshape(-1), device, dtype=dtype).reshape(B, M, N)
    bar_a = a_samps.mean(dim=1)
    bar_a = bar_a / torch.linalg.norm(bar_a, dim=-1, keepdim=True).clamp_min(1e-12)

    snr_lin = 10.0 ** (snr_db / 10.0)
    sigma_s2 = snr_lin * cfg.noise_var
    sigma_s = torch.sqrt(sigma_s2).to(torch.float32)

    inr_lin = 10.0 ** (cfg.INR_dB / 10.0)
    sigma_i2 = inr_lin * cfg.noise_var

    I = cplx_eye(N, device, dtype=dtype).unsqueeze(0).expand(B, -1, -1)
    Rin_true = cfg.noise_var * I
    for k in range(A_j.shape[-1]):
        aj = A_j[:, :, k]
        Rin_true = Rin_true + sigma_i2 * (aj[:, :, None] * torch.conj(aj[:, None, :]))
    Rin_true = hermitize(Rin_true)

    s = sample_complex_gaussian((B, L), device, dtype=dtype) * sigma_s[:, None].to(dtype)
    X = a_true[:, :, None] * s[:, None, :]

    for k in range(A_j.shape[-1]):
        u = sample_complex_gaussian((B, L), device, dtype=dtype) * math.sqrt(sigma_i2)
        X = X + A_j[:, :, k][:, :, None] * u[:, None, :]

    n = sample_complex_gaussian((B, N, L), device, dtype=dtype) * math.sqrt(cfg.noise_var)
    X = X + n

    Rhat = (X @ torch.conj(X.transpose(-1, -2))) / float(L)
    Rhat = hermitize(Rhat)

    result = {
        "Rhat": Rhat,
        "Rin_true": Rin_true,
        "a_true": a_true,
        "a_nom": a_nom,
        "bar_a": bar_a,
        "A_j": A_j,
        "sigma_s2": sigma_s2.to(torch.float32),
        "pos_nom": pos_nom,
        "array_type": array_type,
        "error_type": error_type,
    }
    if return_snapshots:
        result["snapshots"] = X
    return result


def _sidelobe_uniform_grid(theta_s_nom_deg: float,
                           exclude_deg: float,
                           step_deg: float,
                           device) -> torch.Tensor:
    """Uniform theta grid outside the SOI sector."""
    left = torch.arange(-90.0, float(theta_s_nom_deg) - exclude_deg + 1e-6, step_deg, device=device)
    right = torch.arange(float(theta_s_nom_deg) + exclude_deg, 90.0 + 1e-6, step_deg, device=device)
    if left.numel() == 0:
        return right
    if right.numel() == 0:
        return left
    return torch.cat([left, right], dim=0)


def _add_noise_floor(Rrec: torch.Tensor, Rref: torch.Tensor, rel_floor: float = 1e-3) -> torch.Tensor:
    """Small diagonal floor to keep reconstructed covariance positive definite."""
    B, N, _ = Rref.shape
    dtype = Rref.dtype
    I = cplx_eye(N, Rref.device, dtype=dtype)[None].expand(B, -1, -1)
    evals = torch.linalg.eigvalsh(hermitize(Rref)).real
    nf = evals[:, :max(1, N // 3)].mean(dim=-1).clamp_min(1e-6)
    return hermitize(Rrec + rel_floor * nf[:, None, None].to(dtype) * I)


@torch.no_grad()
def meps_ipnc_weight(
    Rhat: torch.Tensor,
    a_nom: torch.Tensor,
    pos_nom: torch.Tensor,
    theta_s_nom_deg: float,
    soi_sector_deg: float = 6.0,
    grid_i_step_deg: float = 1.0,
    grid_s_step_deg: float = 1.0,
    rho: float = 1e-3,
    estimate_sv: bool = True,
) -> torch.Tensor:
    """
    MEPS-IPNC baseline.

    1) Use MEPS spectrum P_meps(theta)=1/(epsilon_p * |a(theta)^H R^-1 u1|^2).
    2) Reconstruct IPNC outside the SOI sector.
    3) Optionally reconstruct desired covariance inside the SOI sector and set a_hat = R_s a_nom.
    4) MVDR with reconstructed IPNC and a_hat.
    """
    B, N, _ = Rhat.shape
    device = Rhat.device
    dtype = Rhat.dtype
    I = cplx_eye(N, device, dtype=dtype)[None].expand(B, -1, -1)
    Rl = hermitize(Rhat + rho * I)

    u1 = torch.zeros(N, device=device, dtype=dtype)
    u1[0] = 1.0 + 0.0j
    Rinv_u1 = torch.linalg.solve(Rl, u1[None, :, None].expand(B, -1, -1)).squeeze(-1)  # [B,N]
    eps_p = 1.0 / ((torch.conj(u1)[None, :] * Rinv_u1).sum(dim=-1).real.clamp_min(1e-10))  # [B]

    def meps_power(A: torch.Tensor) -> torch.Tensor:
        # A: [G,N]; return [B,G]
        z = (torch.conj(A)[None, :, :] * Rinv_u1[:, None, :]).sum(dim=-1)  # a^H R^-1 u1
        P = 1.0 / (eps_p[:, None] * abs2(z).clamp_min(1e-12))
        return P / P.mean(dim=-1, keepdim=True).clamp_min(1e-12)

    def reconstruct(A: torch.Tensor, P: torch.Tensor) -> torch.Tensor:
        G = A.shape[0]
        Rrec = torch.zeros_like(Rhat)
        for g in range(G):
            ag = A[g][None, :].expand(B, -1)
            Rrec = Rrec + P[:, g][:, None, None].to(dtype) * ag[:, :, None] * ag.conj()[:, None, :]
        return Rrec / max(1, G)

    # Interference-plus-noise sector: outside SOI sector.
    theta_i = _sidelobe_uniform_grid(theta_s_nom_deg, soi_sector_deg, grid_i_step_deg, device)
    A_i = steering_from_positions(pos_nom, theta_i, device, dtype=dtype)
    R_ipn = reconstruct(A_i, meps_power(A_i))
    R_ipn = _add_noise_floor(R_ipn, Rhat, rel_floor=1e-2)

    if estimate_sv:
        theta_s = torch.arange(
            float(theta_s_nom_deg) - soi_sector_deg,
            float(theta_s_nom_deg) + soi_sector_deg + 1e-6,
            grid_s_step_deg,
            device=device,
        )
        A_s = steering_from_positions(pos_nom, theta_s, device, dtype=dtype)
        R_s = reconstruct(A_s, meps_power(A_s))
        a_hat = (R_s @ a_nom.unsqueeze(-1)).squeeze(-1)
        a_hat = normalize_complex_vec(a_hat)
        # Fallback: avoid rare numerical zero vector.
        bad = torch.linalg.norm(a_hat, dim=-1) < 1e-8
        if bad.any():
            a_hat[bad] = a_nom[bad]
    else:
        a_hat = a_nom

    return mvdr_weight(R_ipn, a_hat)


def _pglq_theta_nodes_weights(
    theta_s_nom_deg: float,
    exclude_deg: float,
    Q: int,
    null_width_u: float,
    device,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Build PGLQ nodes. Subintervals are uniform in u=sin(theta), then mapped back to theta.
    null_width_u is the intended broadened null/spectrum width in u-domain.
    """
    z_np, w_np = np.polynomial.legendre.leggauss(int(Q))
    z = torch.tensor(z_np, device=device, dtype=torch.float32)
    w = torch.tensor(w_np, device=device, dtype=torch.float32)

    dz = float(np.max(np.diff(z_np))) if Q > 1 else 2.0
    interval_width = max(1e-4, 2.0 * float(null_width_u) / max(dz, 1e-6))

    u_left_end = math.sin((float(theta_s_nom_deg) - exclude_deg) * math.pi / 180.0)
    u_right_start = math.sin((float(theta_s_nom_deg) + exclude_deg) * math.pi / 180.0)

    intervals = [(-1.0, max(-1.0, min(1.0, u_left_end))),
                 (max(-1.0, min(1.0, u_right_start)), 1.0)]

    all_theta = []
    all_weight = []
    for ua, ub in intervals:
        if ub <= ua:
            continue
        m = max(1, int(math.ceil((ub - ua) / interval_width)))
        edges = torch.linspace(ua, ub, m + 1, device=device)
        for k in range(m):
            a = edges[k]
            b = edges[k + 1]
            u_nodes = 0.5 * (a + b) + 0.5 * (b - a) * z
            u_nodes = u_nodes.clamp(-1.0 + 1e-6, 1.0 - 1e-6)
            theta_nodes = torch.asin(u_nodes) * 180.0 / math.pi
            weights = 0.5 * (b - a) * w
            all_theta.append(theta_nodes)
            all_weight.append(weights)

    return torch.cat(all_theta), torch.cat(all_weight)


def _capon_reconstruct_weighted(
    Rspec: torch.Tensor,
    Rref: torch.Tensor,
    A: torch.Tensor,
    weights: torch.Tensor,
    rho: float = 1e-3,
) -> torch.Tensor:
    """Weighted reconstruction: sum weight(theta) * P_capon(theta) * a a^H."""
    B, N, _ = Rspec.shape
    device = Rspec.device
    dtype = Rspec.dtype
    I = cplx_eye(N, device, dtype=dtype)[None].expand(B, -1, -1)

    Rl = hermitize(Rspec + rho * I)
    rhs = A.t().unsqueeze(0).expand(B, -1, -1)  # [B,N,G]
    RinvA = torch.linalg.solve(Rl, rhs)
    denom = (A.conj().t().unsqueeze(0) * RinvA).sum(dim=1).real.clamp_min(1e-8)  # [B,G]
    P = 1.0 / denom
    P = P / P.mean(dim=-1, keepdim=True).clamp_min(1e-12)

    Rrec = torch.zeros_like(Rref)
    G = A.shape[0]
    for g in range(G):
        ag = A[g][None, :].expand(B, -1)
        wg = weights[g].to(device=device, dtype=torch.float32)
        Rrec = Rrec + (wg * P[:, g])[:, None, None].to(dtype) * ag[:, :, None] * ag.conj()[:, None, :]
    return _add_noise_floor(Rrec, Rref, rel_floor=1e-2)


@torch.no_grad()
def pglq_incm_weight(
    Rhat: torch.Tensor,
    a_nom: torch.Tensor,
    pos_nom: torch.Tensor,
    theta_s_nom_deg: float,
    exclude_deg: float = 6.0,
    Q: int = 3,
    null_width_u: Optional[float] = None,
    signal_subspace_dim: Optional[int] = None,
    eig_energy_thr: float = 0.90,
    peak_gain: float = 3.0,
    rho: float = 1e-3,
) -> torch.Tensor:
    """
    PGLQ-INCM baseline with peak-retained Capon spectrum broadening.

    - Build signal subspace from principal eigenvectors.
    - Amplify dominant subspace: R_d=(I+gP_s)Rhat(I+gP_s)^H.
    - Apply covariance taper matrix T(m,n)=sin((m-n)Δu)/((m-n)Δu).
    - Reconstruct INCM using piecewise Gauss-Legendre quadrature outside SOI sector.
    """
    B, N, _ = Rhat.shape
    device = Rhat.device
    dtype = Rhat.dtype
    I = cplx_eye(N, device, dtype=dtype)[None].expand(B, -1, -1)

    if null_width_u is None:
        # A practical default close to a 3-dB beamwidth scale in u=sin(theta).
        null_width_u = min(0.35, 1.772 / max(2, N))

    evals, evecs = torch.linalg.eigh(hermitize(Rhat))  # ascending
    idx = torch.argsort(evals, dim=-1, descending=True)
    evecs_desc = torch.gather(evecs, 2, idx[:, None, :].expand(B, N, N))
    evals_desc = torch.gather(evals, 1, idx)

    if signal_subspace_dim is None:
        cs = torch.cumsum(evals_desc.real.clamp_min(0.0), dim=-1)
        total = cs[:, -1:].clamp_min(1e-12)
        L_each = (cs / total >= eig_energy_thr).float().argmax(dim=-1) + 1
        L = int(L_each.float().median().item())
        L = min(max(1, L), N - 1)
    else:
        L = min(max(1, int(signal_subspace_dim)), N - 1)

    Us = evecs_desc[:, :, :L]
    Ps = Us @ Us.conj().transpose(-1, -2)
    Rd = (I + float(peak_gain) * Ps) @ Rhat @ (I + float(peak_gain) * Ps).conj().transpose(-1, -2)
    Rd = hermitize(Rd)

    # Covariance taper matrix T; sinc(x)=sin(x)/x.
    idx_n = torch.arange(N, device=device, dtype=torch.float32)
    diff = idx_n[:, None] - idx_n[None, :]
    x = diff * float(null_width_u)
    T_real = torch.where(torch.abs(x) < 1e-8, torch.ones_like(x), torch.sin(x) / x)
    RT = hermitize(Rd * T_real.to(dtype)[None, :, :])

    theta_nodes, q_weights = _pglq_theta_nodes_weights(
        theta_s_nom_deg=theta_s_nom_deg,
        exclude_deg=exclude_deg,
        Q=Q,
        null_width_u=float(null_width_u),
        device=device,
    )
    A = steering_from_positions(pos_nom, theta_nodes, device, dtype=dtype)
    R_incm = _capon_reconstruct_weighted(RT, Rhat, A, q_weights, rho=rho)

    return mvdr_weight(R_incm, a_nom)


def train_blackbox_model(
    model: nn.Module,
    cfg: SimCfg,
    device,
    epochs: int,
    steps_per_epoch: int,
    batch_size: int,
    L_choices: Tuple[int, ...],
    snr_range: Tuple[float, float],
    error_choices: Tuple[str, ...] = ("angle", "gain_phase", "position", "random_sv", "combined"),
    array_choices: Tuple[str, ...] = ("ula", "uca", "ccaa"),   # ← 新增
    lr: float = 3e-4,
):
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    for ep in range(1, epochs + 1):
        losses = []
        for _ in range(steps_per_epoch):
            array_type = random.choice(array_choices)  # ← 新增
            L = random.choice(L_choices)
            snr = snr_range[0] + (snr_range[1] - snr_range[0]) * random.random()
            err = random.choice(error_choices)

            batch = gen_scene_batch_revision(cfg, batch_size, L, snr, device, array_type=array_type, error_type=err)
            w = model(batch["Rhat"], batch["a_nom"])
            sinr = sinr_out_db(w, batch["a_true"], batch["Rin_true"], batch["sigma_s2"])
            loss = -sinr.mean()

            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            losses.append(loss.item())

        print(f"BlackBox epoch {ep:03d}/{epochs} | train(-mean SINR dB)={np.mean(losses):.3f}")


def train_model_revision(
    model: nn.Module,
    cfg: SimCfg,
    device,
    epochs: int,
    steps_per_epoch: int,
    batch_size: int,
    L_choices: Tuple[int, ...],
    snr_range: Tuple[float, float],
    error_choices: Tuple[str, ...] = ("angle", "gain_phase", "position", "random_sv", "combined"),
    array_choices: Tuple[str, ...] = ("ula", "uca", "ccaa"),   # ← 新增这一行
    lr: float = 3e-4,
):
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    for ep in range(1, epochs + 1):
        losses = []
        for _ in range(steps_per_epoch):
            L = random.choice(L_choices)
            snr = snr_range[0] + (snr_range[1] - snr_range[0]) * random.random()
            err = random.choice(error_choices)
            array_type = random.choice(array_choices)          # ← 新增这一行

            batch = gen_scene_batch_revision(
                cfg, batch_size, L, snr, device,
                array_type=array_type,          # ← 修改这里（原来写死 "ula"）
                error_type=err
            )

            # ... 后面的代码保持不变
            out = model(batch["Rhat"])
            w = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out["tau"], out["rho"], out["lam_diag"])
            sinr = sinr_out_db(w, batch["a_true"], batch["Rin_true"], batch["sigma_s2"])

            reg = 1e-4 * (out["rho"] ** 2).mean() + 1e-4 * (out["tau"] ** 2).mean()
            reg = reg + 1e-5 * (safe_log(out["lam_diag"]) ** 2).mean()
            loss = -sinr.mean() + reg

            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            losses.append(loss.item())

        print(f"Revision train epoch {ep:03d}/{epochs} | train(-mean SINR dB)={np.mean(losses):.3f}")


# Snapshot experiment
SNAPSHOT_COUNTS = (16, 32, 64, 100, 200, 500)
EVALUATION_SNRS_DB = (0.0, 5.0, 10.0)
EVALUATION_ERROR = "combined"
TRAINING_SNAPSHOTS = (16, 32, 48)
TRAINING_SNR_RANGE = (-15.0, 25.0)
TRAINING_ERRORS = ("angle", "gain_phase", "position", "random_sv", "combined")
TRAINING_ARRAYS = ("ula", "uca", "ccaa")

TM_DRO = "Proposed TM-DRO"
CVCNN = "CVCNN (SPL2022)"
IRANI = "Irani DRO (TSP2025)"
WC_QMI = "WC-QMI-A1-LMI (TSP2023)"
MEPS = "MEPS-IPNC (SPL2020)"
PGLQ = "PGLQ-INCM (SP2026)"

# The legend order, colors, markers, dash styles, and widths match the SNR gap plots.
METHOD_STYLES = {
    "Oracle": ("#111111", "o", "-", 2.8),
    "SMI MVDR": ("#4C78A8", "s", ":", 2.4),
    "LSMI": ("#F58518", "^", "--", 2.4),
    WC_QMI: ("#8C564B", "X", "-.", 2.4),
    IRANI: ("#CC79A7", "<", "-", 2.4),
    MEPS: ("#B79F00", "p", "-", 2.4),
    PGLQ: ("#17BECF", "x", "-.", 2.4),
    CVCNN: ("#003F5C", "o", "-", 2.4),
    TM_DRO: ("#D81B60", "*", "-", 3.0),
}


def parse_arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--snr-db", type=float, nargs="+", default=EVALUATION_SNRS_DB,
                        help="Input SNRs in dB, one figure per value, default 0 5 10.")
    parser.add_argument("--snapshots", type=int, nargs="+", default=SNAPSHOT_COUNTS,
                        help="Snapshot counts to compare.")
    parser.add_argument("--out-dir", type=Path,
                        help="Run directory containing checkpoints and a combined results subdirectory.")
    parser.add_argument("--quick", action="store_true",
                        help="Small smoke test, with a separate default output directory.")
    parser.add_argument("--mc-runs", type=int, help="Trials for each regular method, default 300.")
    parser.add_argument("--solver-mc", type=int, help="Trials for each SDP baseline, default 10.")
    parser.add_argument("--warm-epochs", type=int)
    parser.add_argument("--epochs", type=int, help="Mixed-distribution training epochs.")
    parser.add_argument("--steps-per-epoch", type=int)
    parser.add_argument("--batch-size", type=int)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--cpu-threads", type=int, default=min(4, os.cpu_count() or 1))
    args = parser.parse_args()

    defaults = {
        "mc_runs": 8 if args.quick else 300,
        "solver_mc": 1 if args.quick else 10,
        "warm_epochs": 1 if args.quick else 10,
        "epochs": 1 if args.quick else 10,
        "steps_per_epoch": 3 if args.quick else 180,
        "batch_size": 4 if args.quick else 64,
    }
    for option, value in defaults.items():
        if getattr(args, option) is None:
            setattr(args, option, value)
        if getattr(args, option) < 1:
            parser.error(f"--{option.replace('_', '-')} must be positive")
    if not all(math.isfinite(snr) for snr in args.snr_db):
        parser.error("All --snr-db values must be finite")
    args.snr_db = tuple(dict.fromkeys(0.0 if snr == 0.0 else snr for snr in args.snr_db))
    if not math.isfinite(args.lr) or args.lr <= 0:
        parser.error("--lr must be positive and finite")
    if not 0 <= args.seed < 2**32 - 100_000:
        parser.error("--seed must be nonnegative and below 2**32 - 100000")
    if args.cpu_threads < 1:
        parser.error("--cpu-threads must be positive")
    args.snapshots = sorted(set(args.snapshots))
    if args.snapshots[0] < SimCfg().N:
        parser.error(f"Each snapshot count must be at least {SimCfg().N} for SMI MVDR")
    if args.out_dir is None:
        folder = "outputs_snapshot_loss_gap_quick" if args.quick else "outputs_snapshot_loss_gap"
        args.out_dir = Path(__file__).resolve().parent / folder
    return args


def checkpoint_path(out_dir: Path, name: str, cfg: SimCfg, args) -> Path:
    settings = {
        "version": 1,
        "name": name,
        "scene": asdict(cfg),
        "seed": args.seed,
        "warm_epochs": args.warm_epochs,
        "epochs": args.epochs,
        "steps_per_epoch": args.steps_per_epoch,
        "batch_size": args.batch_size,
        "lr": args.lr,
    }
    key = hashlib.sha256(json.dumps(settings, sort_keys=True).encode("utf-8")).hexdigest()[:16]
    return out_dir / "checkpoints" / f"{name}_{key}.pt"


def save_checkpoint(model: nn.Module, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with NamedTemporaryFile(mode="wb", suffix=".tmp", dir=path.parent, delete=False) as temporary:
            temp_path = Path(temporary.name)
            torch.save(model.state_dict(), temporary)
        os.replace(temp_path, path)
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def load_checkpoint(model: nn.Module, path: Path, device) -> bool:
    if not path.is_file():
        return False
    try:
        model.load_state_dict(torch.load(path, map_location=device, weights_only=True))
    except (OSError, RuntimeError, EOFError, ValueError, pickle.UnpicklingError) as error:
        print(f"Cannot reuse {path.name}: {error}. Training this model again.", flush=True)
        return False
    print(f"Loaded checkpoint: {path.name}", flush=True)
    return True


def train_models(cfg: SimCfg, device, args):
    training = {
        "steps_per_epoch": args.steps_per_epoch,
        "batch_size": args.batch_size,
        "L_choices": TRAINING_SNAPSHOTS,
        "snr_range": TRAINING_SNR_RANGE,
    }
    mixed = {"error_choices": TRAINING_ERRORS, "array_choices": TRAINING_ARRAYS}
    set_seed(args.seed)
    proposed = EigenTokenSSM(N=cfg.N, d_model=96, n_layers=3, dropout=0.05).to(device)
    path = checkpoint_path(args.out_dir, "tm_dro", cfg, args)
    if not load_checkpoint(proposed, path, device):
        print("\nTM-DRO warm-up: ULA, angle error", flush=True)
        train_model(proposed, cfg, device, epochs=args.warm_epochs, lr=args.lr, **training)
        print("\nTM-DRO mixed-distribution training", flush=True)
        train_model_revision(proposed, cfg, device, epochs=args.epochs, lr=args.lr, **training, **mixed)
        save_checkpoint(proposed, path)

    set_seed(args.seed + 1)
    cvcnn = CVCNNBeamformer(cfg.N).to(device)
    path = checkpoint_path(args.out_dir, "cvcnn", cfg, args)
    if not load_checkpoint(cvcnn, path, device):
        print("\nCVCNN warm-up: ULA, angle error", flush=True)
        train_blackbox_model(
            cvcnn, cfg, device, epochs=args.warm_epochs, lr=args.lr * 0.5,
            error_choices=("angle",), array_choices=("ula",), **training,
        )
        print("\nCVCNN mixed-distribution training", flush=True)
        train_blackbox_model(
            cvcnn, cfg, device, epochs=args.epochs, lr=args.lr * 0.5, **training, **mixed,
        )
        save_checkpoint(cvcnn, path)
    return proposed.eval(), cvcnn.eval()


@torch.no_grad()
def evaluate_at_snapshot_count(cfg, scene, L, proposed, cvcnn, solver_mc):
    """Evaluate the selected methods on one prefix of the shared trial batch."""
    samples = scene["snapshots"][..., :L]
    Rhat = hermitize((samples @ samples.transpose(-1, -2).conj()) / float(L))
    Rin = scene["Rin_true"]
    a_true = scene["a_true"]
    a_nom = scene["a_nom"]
    power = scene["sigma_s2"]
    pos = scene["pos_nom"]

    def scores(weights):
        n = weights.shape[0]
        values = sinr_out_db(weights, a_true[:n], Rin[:n], power[:n])
        return values.cpu().numpy().astype(np.float64)

    params = proposed(Rhat)
    proposed_weights = robust_beamformer_from_params(
        Rhat, scene["bar_a"], params["tau"], params["rho"], params["lam_diag"],
    )
    failures_wc = []
    failures_irani = []
    results = {
        "Oracle": scores(mvdr_weight(Rin, a_true)),
        "SMI MVDR": scores(mvdr_weight(Rhat, a_nom)),
        "LSMI": scores(lsmi_weight(Rhat, a_nom, beta=0.1)),
        WC_QMI: scores(wc_qmi_a1_lmi_weight(
            Rhat[:solver_mc], a_nom[:solver_mc],
            solver="SCS", max_iters=500, eps=1e-3, fallback_indices=failures_wc,
        )),
        IRANI: scores(irani_dro_weight(
            Rhat[:solver_mc], a_nom[:solver_mc], max_iter=0, fallback_indices=failures_irani,
        )),
        MEPS: scores(meps_ipnc_weight(
            Rhat, a_nom, pos, theta_s_nom_deg=cfg.theta_s_nom_deg,
            soi_sector_deg=6.0, grid_i_step_deg=2.0, grid_s_step_deg=1.0,
            rho=1e-3, estimate_sv=True,
        )),
        PGLQ: scores(pglq_incm_weight(
            Rhat, a_nom, pos, theta_s_nom_deg=cfg.theta_s_nom_deg, exclude_deg=6.0,
            Q=3, null_width_u=None, signal_subspace_dim=4, peak_gain=3.0, rho=1e-3,
        )),
        CVCNN: scores(cvcnn(Rhat, a_nom)),
        TM_DRO: scores(proposed_weights),
    }
    fallbacks = {WC_QMI: len(failures_wc), IRANI: len(failures_irani)}
    return results, fallbacks


def run_snapshot_sweep(cfg, device, args, proposed, cvcnn, snr_db):
    # Reuse the random realizations across SNRs while scaling the desired signal.
    set_seed(args.seed + 100_000)
    scene = gen_scene_batch_revision(
        cfg, args.mc_runs, max(args.snapshots), snr_db, device,
        array_type="ula", error_type=EVALUATION_ERROR, return_snapshots=True,
    )
    curves = {name: [] for name in METHOD_STYLES}
    rows = []
    solver_mc = min(args.solver_mc, args.mc_runs)
    for L in args.snapshots:
        print(f"\nEvaluating SNR = {snr_db:g} dB, L = {L}", flush=True)
        results, fallbacks = evaluate_at_snapshot_count(cfg, scene, L, proposed, cvcnn, solver_mc)
        for name in curves:
            values = results[name]
            oracle = results["Oracle"][:len(values)]
            gaps = oracle - values
            if gaps.size == 0 or not np.isfinite(gaps).all():
                raise RuntimeError(f"{name} produced invalid SINR at SNR={snr_db:g} dB, L={L}")
            gap = float(gaps.mean())
            count = fallbacks.get(name, 0)
            if count:
                print(f"  {name}: solver fallback on {count}/{len(values)} trials", flush=True)
            curves[name].append(gap)
            rows.append([
                snr_db, L, name, len(values), float(values.mean()),
                float(oracle.mean()), gap, count, EVALUATION_ERROR,
            ])
            print(f"  {name:25s} gap {gap:8.3f} dB | N_MC={len(values)}", flush=True)
    return curves, rows


def plot_snapshot_loss_gap(snapshots, curves, out_base: Path):
    set_pub_style()
    fig, ax = plt.subplots(figsize=(7.2, 4.1))
    ax.set_xscale("log")
    for name, (color, marker, linestyle, linewidth) in METHOD_STYLES.items():
        ax.plot(
            snapshots, curves[name], label=name, color=color, marker=marker,
            linestyle=linestyle, linewidth=linewidth,
            markersize=7.8 if name == TM_DRO else 5.8, markerfacecolor=color,
            markeredgecolor="white", markeredgewidth=0.55, markevery=1,
        )
    ax.set_xticks(snapshots, [str(L) for L in snapshots])
    ax.set_xlim(snapshots[0] / 1.15, snapshots[-1] * 1.15)
    ax.set_xlabel(r"Snapshots $L$ (log scale)")
    ax.set_ylabel("SINR loss gap (dB)")
    apply_axis_style(ax)
    ax.axhline(0.0, color="#666666", linestyle="--", linewidth=0.9, alpha=0.70, zorder=0)
    handles, labels = ax.get_legend_handles_labels()
    fig.legend(
        handles, labels, loc="lower center", bbox_to_anchor=(0.5, 0.012),
        ncol=3, frameon=False, fancybox=False, fontsize=7.4,
        handlelength=2.1, columnspacing=1.1, handletextpad=0.45, borderaxespad=0.0,
    )
    fig.subplots_adjust(left=0.12, right=0.985, top=0.975, bottom=0.32)
    savefig_dual(str(out_base))
    plt.close(fig)


def main():
    args = parse_arguments()
    if "SCS" not in cp.installed_solvers():
        raise SystemExit("SCS is required for the two SDP baselines. Install it with: python -m pip install scs")
    cuda_available = torch.cuda.is_available()
    if args.device == "cuda" and not cuda_available:
        raise SystemExit("CUDA was requested but is unavailable in this PyTorch installation.")
    use_cuda = cuda_available and args.device != "cpu"
    device = torch.device("cuda" if use_cuda else "cpu")
    torch.set_num_threads(args.cpu_threads)
    result_dir = args.out_dir / EVALUATION_ERROR
    result_dir.mkdir(parents=True, exist_ok=True)
    cfg = SimCfg()
    snr_list = ", ".join(f"{snr:g}" for snr in args.snr_db)
    print(
        f"Device {device} | SNRs {snr_list} dB | ULA | {EVALUATION_ERROR} mismatch | "
        f"MC {args.mc_runs}, SDP MC {min(args.solver_mc, args.mc_runs)}",
        flush=True,
    )
    proposed, cvcnn = train_models(cfg, device, args)
    rows = []
    curves_by_snr = {}
    for snr_db in args.snr_db:
        curves, snr_rows = run_snapshot_sweep(cfg, device, args, proposed, cvcnn, snr_db)
        curves_by_snr[snr_db] = curves
        rows.extend(snr_rows)
    for snr_db, curves in curves_by_snr.items():
        snr_text = str(snr_db)
        snr_tag = snr_text[:-2] if snr_text.endswith(".0") else snr_text.replace(".", "p")
        output = result_dir / f"fig_loss_gap_vs_L_{snr_tag}dB"
        plot_snapshot_loss_gap(args.snapshots, curves, output)
        print(f"\nSaved {output}.pdf and {output}.png.", flush=True)

    csv_path = result_dir / "data_loss_gap_vs_L.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "snr_db", "snapshots_L", "method", "n_mc", "mean_sinr_db",
            "paired_mean_oracle_sinr_db", "mean_loss_gap_db", "solver_fallbacks",
            "error_type",
        ])
        writer.writerows(rows)
    print(f"Saved {csv_path}.", flush=True)


if __name__ == "__main__":
    main()
