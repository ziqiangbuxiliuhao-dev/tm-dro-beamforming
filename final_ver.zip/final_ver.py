# -*- coding: utf-8 -*-

import argparse
import math
import os
import random
from dataclasses import dataclass
from typing import Dict, Tuple, List, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator


# =========================================================
# Publication style (PRINT-READY, grid & fonts visible)
# =========================================================
def set_pub_style():
    """
    Print-ready style:
      - Times-like font
      - strong but non-intrusive grid (major/minor)
      - ticks/spines visible after downscaling
      - PDF embeds TrueType fonts (fonttype 42)
    """
    mpl.rcParams.update({
        # ---- Fonts ----
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "Nimbus Roman", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "axes.unicode_minus": False,

        # ---- Save settings ----
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,

        # ---- Sizes (paper-like) ----
        "axes.labelsize": 10,
        "axes.titlesize": 10,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 8,

        # ---- Lines ----
        "lines.linewidth": 2.0,
        "lines.markersize": 5.2,

        # ---- Axes ----
        "axes.linewidth": 1.0,
        "axes.grid": False,  # we control grid per-axis for major/minor
        "axes.spines.top": False,
        "axes.spines.right": False,

        # ---- Ticks ----
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.size": 4.0,
        "ytick.major.size": 4.0,
        "xtick.major.width": 1.0,
        "ytick.major.width": 1.0,
        "xtick.minor.size": 2.5,
        "ytick.minor.size": 2.5,
        "xtick.minor.width": 0.9,
        "ytick.minor.width": 0.9,
    })


def apply_axis_style(ax: plt.Axes):
    """
    Ensure grid and tick appearance are 'journal visible' after downscale/print.
    """
    # Minor ticks
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))

    # Major grid (visible, not too dark)
    ax.grid(True, which="major", linestyle="-", linewidth=0.8, alpha=0.35)

    # Minor grid (lighter)
    ax.grid(True, which="minor", linestyle="--", linewidth=0.6, alpha=0.22)

    # Spines a bit stronger
    for side in ["left", "bottom"]:
        ax.spines[side].set_linewidth(1.0)

    # Keep ticks crisp
    ax.tick_params(which="both", top=False, right=False)


def savefig_dual(path_base: str, dpi: int = 450):
    """
    Save both PDF (vector) and PNG (high-dpi raster preview).
    """
    plt.savefig(path_base + ".pdf")
    plt.savefig(path_base + ".png", dpi=dpi)


def legend_outside_bottom(ax: plt.Axes, max_cols: int = 4, y_offset: float = -0.26):
    """
    Put legend outside at bottom with clear frame.
    """
    handles, labels = ax.get_legend_handles_labels()
    n_items = len(labels)
    if n_items <= 6:
        ncol = 2
    elif n_items <= 9:
        ncol = 3
    else:
        ncol = max_cols

    leg = ax.legend(
        handles, labels,
        loc="upper center",
        bbox_to_anchor=(0.5, y_offset),
        ncol=ncol,
        frameon=True,
        fancybox=False,   # journal-like
        borderaxespad=0.0,
        columnspacing=1.1,
        handlelength=2.0,
        handletextpad=0.6,
    )
    leg.get_frame().set_linewidth(0.8)
    leg.get_frame().set_alpha(0.95)

    # Make room for legend
    plt.subplots_adjust(bottom=0.32)


# =========================================================
# CSV / TeX table IO
# =========================================================
def write_csv(path: str, header: List[str], rows: List[List]):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(",".join(header) + "\n")
        for r in rows:
            f.write(",".join([str(x) for x in r]) + "\n")


def write_tex_table(path: str, caption: str, label: str,
                    colspec: str, header_lines: List[str], body_lines: List[str],
                    notes: Optional[str] = None, footnotesize: bool = True):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("% Auto-generated table\n")
        f.write("\\begin{table*}[t]\n\\centering\n")
        f.write(f"\\caption{{{caption}}}\n")
        f.write(f"\\label{{{label}}}\n")
        if footnotesize:
            f.write("\\footnotesize\n")
        f.write("\\setlength{\\tabcolsep}{3.0pt}\n")
        f.write("\\renewcommand{\\arraystretch}{0.85}\n")
        f.write(f"\\begin{{tabular}}{{{colspec}}}\n")
        f.write("\\toprule\n")
        for hl in header_lines:
            f.write(hl + "\n")
        f.write("\\midrule\n")
        for bl in body_lines:
            f.write(bl + "\n")
        f.write("\\bottomrule\n")
        f.write("\\end{tabular}\n")
        if notes is not None and len(notes) > 0:
            f.write("\\vspace{0.25em}\n")
            f.write("{\\scriptsize " + notes + "}\n")
        f.write("\\end{table*}\n")


# =========================================================
# Repro
# =========================================================
def set_seed(seed: int = 0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# =========================================================
# Complex helpers
# =========================================================
def cplx_eye(n: int, device, dtype=torch.complex64):
    return torch.eye(n, device=device, dtype=dtype)


def hermitize(R: torch.Tensor) -> torch.Tensor:
    return 0.5 * (R + torch.conj(R.transpose(-1, -2)))


def steering_ula(N: int, d_over_lambda: float, theta_deg: torch.Tensor, device, dtype=torch.complex64) -> torch.Tensor:
    """
    ULA steering: a_n = exp(j*2*pi*d/lambda*n*sin(theta)), normalized to ||a||2=1
    theta_deg: [B]
    return: [B, N]
    """
    theta = theta_deg * math.pi / 180.0
    n = torch.arange(N, device=device, dtype=torch.float32)[None, :]
    phase = 2.0 * math.pi * d_over_lambda * n * torch.sin(theta)[:, None]
    a = torch.exp(1j * phase.to(torch.complex64))
    a = a / torch.linalg.norm(a, dim=-1, keepdim=True).clamp_min(1e-12)
    return a.to(dtype)


def solve(A: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    return torch.linalg.solve(A, b.unsqueeze(-1)).squeeze(-1)


def abs2(x: torch.Tensor) -> torch.Tensor:
    return (x.real * x.real + x.imag * x.imag)


def safe_log(x: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    return torch.log(x.clamp_min(eps))


def trace_batch(R: torch.Tensor) -> torch.Tensor:
    return R.diagonal(dim1=-2, dim2=-1).sum(-1)


def quad_form(w: torch.Tensor, R: torch.Tensor) -> torch.Tensor:
    v = (torch.conj(w).unsqueeze(1) @ (R @ w.unsqueeze(-1))).squeeze(-1).squeeze(-1)
    return v.real


def display_offset_db(N: int) -> float:
    return float(10.0 * np.log10(max(1, N)))


# =========================================================
# Simulation config
# =========================================================
@dataclass
class SimCfg:
    N: int = 10
    d_over_lambda: float = 0.5
    theta_s_nom_deg: float = -5.0
    mismatch_std_deg: float = 2.0
    theta_js_deg: Tuple[float, float, float] = (20.0, 50.0, 65.0)
    INR_dB: float = 20.0
    noise_var: float = 1.0
    a_samples_M: int = 16


def sample_complex_gaussian(shape, device, dtype=torch.complex64):
    x = torch.randn(*shape, device=device, dtype=torch.float32)
    y = torch.randn(*shape, device=device, dtype=torch.float32)
    z = (x + 1j * y) / math.sqrt(2.0)
    return z.to(dtype)


def gen_scene_batch(cfg: SimCfg, B: int, L: int, snr_db: torch.Tensor, device) -> Dict[str, torch.Tensor]:
    """
    Generates:
      Rhat: sample covariance
      Rin_true: true interference+noise covariance (no desired signal)
      a_true: desired steering with mismatch
      a_nom: nominal desired steering
      bar_a: averaged steering samples
      A_j: interferer steering stack [B,N,3]
      sigma_s2: desired power (linear)
    """
    N = cfg.N
    dtype = torch.complex64

    snr_lin = (10.0 ** (snr_db / 10.0)).to(torch.float32)
    sigma_s2 = snr_lin * cfg.noise_var
    sigma_s = torch.sqrt(sigma_s2).to(torch.float32)

    theta_s_true = (
        torch.tensor(cfg.theta_s_nom_deg, device=device, dtype=torch.float32)
        + torch.randn(B, device=device, dtype=torch.float32) * cfg.mismatch_std_deg
    )
    a_true = steering_ula(N, cfg.d_over_lambda, theta_s_true, device, dtype=dtype)

    theta_s_nom = torch.full((B,), float(cfg.theta_s_nom_deg), device=device, dtype=torch.float32)
    a_nom = steering_ula(N, cfg.d_over_lambda, theta_s_nom, device, dtype=dtype)

    inr_lin = 10.0 ** (cfg.INR_dB / 10.0)
    sigma_i2 = inr_lin * cfg.noise_var

    theta_j = [torch.full((B,), float(th), device=device, dtype=torch.float32) for th in cfg.theta_js_deg]
    a_j = [steering_ula(N, cfg.d_over_lambda, th, device, dtype=dtype) for th in theta_j]
    A_j = torch.stack(a_j, dim=-1)  # [B,N,3]

    I = cplx_eye(N, device, dtype=dtype).unsqueeze(0).expand(B, -1, -1)
    Rin_true = cfg.noise_var * I
    for aj in a_j:
        Rin_true = Rin_true + sigma_i2 * (aj[:, :, None] * torch.conj(aj[:, None, :]))
    Rin_true = hermitize(Rin_true)

    s = sample_complex_gaussian((B, L), device, dtype=dtype) * sigma_s[:, None].to(dtype)
    u = [sample_complex_gaussian((B, L), device, dtype=dtype) * math.sqrt(sigma_i2) for _ in range(3)]
    n = sample_complex_gaussian((B, N, L), device, dtype=dtype) * math.sqrt(cfg.noise_var)

    X = a_true[:, :, None] * s[:, None, :]
    for aj, uj in zip(a_j, u):
        X = X + aj[:, :, None] * uj[:, None, :]
    X = X + n

    Rhat = (X @ torch.conj(X.transpose(-1, -2))) / float(L)
    Rhat = hermitize(Rhat)

    M = cfg.a_samples_M
    theta_samples = (
        torch.tensor(cfg.theta_s_nom_deg, device=device, dtype=torch.float32)[None, None]
        + torch.randn(B, M, device=device, dtype=torch.float32) * cfg.mismatch_std_deg
    )
    a_samps = steering_ula(N, cfg.d_over_lambda, theta_samples.reshape(-1), device, dtype=dtype).reshape(B, M, N)
    bar_a = a_samps.mean(dim=1)
    bar_a = bar_a / torch.linalg.norm(bar_a, dim=-1, keepdim=True).clamp_min(1e-12)

    return {
        "Rhat": Rhat,
        "Rin_true": Rin_true,
        "a_true": a_true,
        "a_nom": a_nom,
        "bar_a": bar_a,
        "A_j": A_j,
        "sigma_s2": sigma_s2.to(torch.float32),
    }


@torch.no_grad()
def gen_scene_custom(cfg: SimCfg, B: int, L: int, snr_db: float, device,
                     inr_db: Optional[float] = None,
                     mismatch_std_deg: Optional[float] = None,
                     theta_js_deg: Optional[Tuple[float, float, float]] = None) -> Dict[str, torch.Tensor]:
    old_inr, old_mis, old_js = cfg.INR_dB, cfg.mismatch_std_deg, cfg.theta_js_deg
    if inr_db is not None:
        cfg.INR_dB = float(inr_db)
    if mismatch_std_deg is not None:
        cfg.mismatch_std_deg = float(mismatch_std_deg)
    if theta_js_deg is not None:
        cfg.theta_js_deg = tuple(theta_js_deg)

    snr_tensor = torch.full((B,), float(snr_db), device=device)
    batch = gen_scene_batch(cfg, B, L, snr_tensor, device)

    cfg.INR_dB, cfg.mismatch_std_deg, cfg.theta_js_deg = old_inr, old_mis, old_js
    return batch


# =========================================================
# Models: token mixing blocks + variants
# =========================================================
class SSMBlock(nn.Module):
    def __init__(self, d_model: int, kernel_size: int = 7, expansion: int = 2, dropout: float = 0.0):
        super().__init__()
        self.ln = nn.LayerNorm(d_model)
        self.dw = nn.Conv1d(d_model, d_model, kernel_size=kernel_size,
                            padding=kernel_size // 2, groups=d_model)
        self.pw1 = nn.Linear(d_model, d_model * expansion * 2)
        self.pw2 = nn.Linear(d_model * expansion, d_model)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.ln(x)
        h = h + self.dw(h.transpose(1, 2)).transpose(1, 2)
        u = self.pw1(h)
        a, b = u.chunk(2, dim=-1)
        h = F.silu(a) * torch.sigmoid(b)
        h = self.pw2(h)
        h = self.drop(h)
        return x + h


def eig_tokens(Rhat: torch.Tensor) -> torch.Tensor:
    """Tokens [B,N,3] = [log_e, log_ratio, idx]."""
    B, N, _ = Rhat.shape
    evals = torch.linalg.eigvalsh(Rhat).real
    evals = torch.flip(evals, dims=[-1])
    log_e = safe_log(evals + 1e-8)
    log_ratio = log_e - safe_log(evals.sum(dim=-1, keepdim=True) + 1e-8)
    idx = (torch.arange(N, device=Rhat.device, dtype=torch.float32)[None, :] / max(1, N - 1)).expand(B, -1)
    return torch.stack([log_e, log_ratio, idx], dim=-1)


class EigenTokenSSM(nn.Module):
    """Full proposed: token mixing -> tau,rho,lam_diag + embed."""
    def __init__(self, N: int, d_model: int = 96, n_layers: int = 3, dropout: float = 0.05):
        super().__init__()
        self.N = N
        self.proj = nn.Linear(3, d_model)
        self.blocks = nn.ModuleList([SSMBlock(d_model, 7, 2, dropout) for _ in range(n_layers)])
        self.ln_out = nn.LayerNorm(d_model)

        self.head_tau = nn.Sequential(nn.Linear(d_model, d_model // 2), nn.SiLU(), nn.Linear(d_model // 2, 1))
        self.head_rho = nn.Sequential(nn.Linear(d_model, d_model // 2), nn.SiLU(), nn.Linear(d_model // 2, 1))
        self.head_lam = nn.Sequential(nn.Linear(d_model, d_model), nn.SiLU(), nn.Linear(d_model, N))

        self.tau_scale = 2.0
        self.rho_scale = 0.5

    def forward(self, Rhat: torch.Tensor) -> Dict[str, torch.Tensor]:
        tok = eig_tokens(Rhat)
        x = self.proj(tok)
        for blk in self.blocks:
            x = blk(x)
        x = self.ln_out(x)
        g = x.mean(dim=1)

        tau = F.softplus(self.head_tau(g)).squeeze(-1) * self.tau_scale + 1e-6
        rho = F.softplus(self.head_rho(g)).squeeze(-1) * self.rho_scale + 1e-6
        lam = F.softplus(self.head_lam(g)) + 1e-4
        return {"tau": tau, "rho": rho, "lam_diag": lam, "embed": g}


class EigenTokenSSM_NoLam(EigenTokenSSM):
    """Ablation: lam fixed ones, still mixing."""
    def forward(self, Rhat: torch.Tensor) -> Dict[str, torch.Tensor]:
        out = super().forward(Rhat)
        B, N, _ = Rhat.shape
        out["lam_diag"] = torch.ones(B, N, device=Rhat.device, dtype=torch.float32)
        return out


class EigenMLPParam(nn.Module):
    """Reduced: learn tau,rho only from per-token MLP (no mixing), lam=1."""
    def __init__(self, N: int, hidden: int = 128, dropout: float = 0.05):
        super().__init__()
        self.N = N
        self.fc1 = nn.Linear(3, hidden)
        self.fc2 = nn.Linear(hidden, hidden)
        self.drop = nn.Dropout(dropout)
        self.out_tau = nn.Linear(hidden, 1)
        self.out_rho = nn.Linear(hidden, 1)
        self.tau_scale = 2.0
        self.rho_scale = 0.5

    def forward(self, Rhat: torch.Tensor) -> Dict[str, torch.Tensor]:
        tok = eig_tokens(Rhat)
        h = F.silu(self.fc1(tok))
        h = self.drop(F.silu(self.fc2(h)))
        g = h.mean(dim=1)
        tau = F.softplus(self.out_tau(g)).squeeze(-1) * self.tau_scale + 1e-6
        rho = F.softplus(self.out_rho(g)).squeeze(-1) * self.rho_scale + 1e-6
        B, N, _ = Rhat.shape
        lam = torch.ones(B, N, device=Rhat.device, dtype=torch.float32)
        return {"tau": tau, "rho": rho, "lam_diag": lam, "embed": g}


class EigenTokenMLP(nn.Module):
    """Ablation: NO mixing. Per-token MLP -> mean pool -> heads for tau,rho,lam."""
    def __init__(self, N: int, d_model: int = 96, hidden: int = 192, dropout: float = 0.05):
        super().__init__()
        self.N = N
        self.mlp = nn.Sequential(
            nn.Linear(3, hidden), nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, d_model), nn.SiLU(),
        )
        self.head_tau = nn.Sequential(nn.Linear(d_model, d_model // 2), nn.SiLU(), nn.Linear(d_model // 2, 1))
        self.head_rho = nn.Sequential(nn.Linear(d_model, d_model // 2), nn.SiLU(), nn.Linear(d_model // 2, 1))
        self.head_lam = nn.Sequential(nn.Linear(d_model, d_model), nn.SiLU(), nn.Linear(d_model, N))
        self.tau_scale = 2.0
        self.rho_scale = 0.5

    def forward(self, Rhat: torch.Tensor) -> Dict[str, torch.Tensor]:
        tok = eig_tokens(Rhat)
        x = self.mlp(tok)
        g = x.mean(dim=1)
        tau = F.softplus(self.head_tau(g)).squeeze(-1) * self.tau_scale + 1e-6
        rho = F.softplus(self.head_rho(g)).squeeze(-1) * self.rho_scale + 1e-6
        lam = F.softplus(self.head_lam(g)) + 1e-4
        return {"tau": tau, "rho": rho, "lam_diag": lam, "embed": g}


class OnlyRhoModel(nn.Module):
    """Ablation: learn rho only. tau=0, lam=1."""
    def __init__(self, N: int, hidden: int = 128, dropout: float = 0.05):
        super().__init__()
        self.N = N
        self.fc1 = nn.Linear(3, hidden)
        self.fc2 = nn.Linear(hidden, hidden)
        self.drop = nn.Dropout(dropout)
        self.out_rho = nn.Linear(hidden, 1)
        self.rho_scale = 0.5

    def forward(self, Rhat: torch.Tensor) -> Dict[str, torch.Tensor]:
        tok = eig_tokens(Rhat)
        h = F.silu(self.fc1(tok))
        h = self.drop(F.silu(self.fc2(h)))
        g = h.mean(dim=1)
        rho = F.softplus(self.out_rho(g)).squeeze(-1) * self.rho_scale + 1e-6
        B, N, _ = Rhat.shape
        tau = torch.zeros(B, device=Rhat.device, dtype=torch.float32)
        lam = torch.ones(B, N, device=Rhat.device, dtype=torch.float32)
        return {"tau": tau, "rho": rho, "lam_diag": lam, "embed": g}


# =========================================================
# Differentiable robust beamformer (SOC-style scaling on MVDR ray)
# =========================================================
def robust_beamformer_from_params(Rhat, bar_a, tau, rho, lam_diag) -> torch.Tensor:
    """
    v = (Rhat + rho I)^-1 bar_a
    alpha = 1 / ( softplus( Re(v^H bar_a) - tau * sqrt(sum |v|^2 / lam) ) + eps )
    w = alpha v
    """
    B, N, _ = Rhat.shape
    dtype = Rhat.dtype
    I = cplx_eye(N, Rhat.device, dtype=dtype)[None].expand(B, -1, -1)

    Rl = Rhat + rho[:, None, None].to(dtype) * I
    v = solve(Rl, bar_a)
    vhb = (torch.conj(v) * bar_a).sum(dim=-1).real

    inv_lam = 1.0 / lam_diag.clamp_min(1e-6)
    maha = torch.sqrt((abs2(v) * inv_lam).sum(dim=-1).clamp_min(1e-12))

    denom_raw = vhb - tau * maha
    denom = F.softplus(denom_raw) + 1e-6
    alpha = 1.0 / denom
    return v * alpha[:, None].to(dtype)


# =========================================================
# Baselines
# =========================================================
def mvdr_weight(R: torch.Tensor, a: torch.Tensor) -> torch.Tensor:
    """
    MVDR: w = R^{-1} a / (a^H R^{-1} a)
    """
    x = solve(R, a)  # R^{-1} a
    denom = (torch.conj(a) * x).sum(dim=-1)  # complex, should be ~real
    denom_real = denom.real.clamp_min(1e-12)
    return x / denom_real.unsqueeze(-1).to(x.dtype)


def dl_mvdr_weight(Rhat: torch.Tensor, a: torch.Tensor, rho: float) -> torch.Tensor:
    B, N, _ = Rhat.shape
    I = cplx_eye(N, Rhat.device, dtype=Rhat.dtype)[None].expand(B, -1, -1)
    return mvdr_weight(Rhat + rho * I, a)


def lsmi_weight(Rhat: torch.Tensor, a: torch.Tensor, beta: float = 0.1) -> torch.Tensor:
    B, N, _ = Rhat.shape
    I = cplx_eye(N, Rhat.device, dtype=Rhat.dtype)[None].expand(B, -1, -1)
    tr = trace_batch(Rhat).real
    delta = beta * (tr / float(N)).to(torch.float32)
    Rl = Rhat + delta[:, None, None].to(Rhat.dtype) * I
    return mvdr_weight(Rl, a)


def rcb_weight(Rhat: torch.Tensor, a_nom: torch.Tensor, eps: float = 0.15) -> torch.Tensor:
    v = solve(Rhat, a_nom)
    v = v / torch.linalg.norm(v, dim=-1, keepdim=True).clamp_min(1e-12)
    a_worst = a_nom - eps * v
    a_worst = a_worst / torch.linalg.norm(a_worst, dim=-1, keepdim=True).clamp_min(1e-12)
    return mvdr_weight(Rhat, a_worst)


def subspace_mvdr_weight(Rhat: torch.Tensor, a: torch.Tensor, K: int = 3) -> torch.Tensor:
    B, N, _ = Rhat.shape
    evals, evecs = torch.linalg.eigh(Rhat)
    Ui = evecs[..., -(K):]
    I = torch.eye(N, device=Rhat.device, dtype=Rhat.dtype)[None].expand(B, -1, -1)
    P = I - Ui @ Ui.conj().transpose(-1, -2)
    Rproj = hermitize(P @ Rhat @ P)
    aproj = (P @ a.unsqueeze(-1)).squeeze(-1)
    return mvdr_weight(Rproj + 1e-6 * I, aproj)


def shrinkage_mvdr_weight(Rhat: torch.Tensor, a: torch.Tensor, alpha: float = 0.1) -> torch.Tensor:
    B, N, _ = Rhat.shape
    dtype = Rhat.dtype
    I = cplx_eye(N, Rhat.device, dtype=dtype)[None].expand(B, -1, -1)
    tr = trace_batch(Rhat).real.clamp_min(1e-12)
    mu = (tr / float(N)).to(torch.float32)
    Rsh = (1.0 - alpha) * Rhat + alpha * mu[:, None, None].to(dtype) * I
    Rsh = hermitize(Rsh)
    return mvdr_weight(Rsh, a)


def lcmv_weight(R: torch.Tensor, C: torch.Tensor, f: torch.Tensor) -> torch.Tensor:
    Rinvc = torch.linalg.solve(R, C)
    G = C.conj().transpose(-1, -2) @ Rinvc
    x = torch.linalg.solve(G, f.unsqueeze(-1)).squeeze(-1)
    w = Rinvc @ x.unsqueeze(-1)
    return w.squeeze(-1)


def rvo_lcmv_weight(Rhat: torch.Tensor, a_nom: torch.Tensor, A_j: torch.Tensor,
                    eps: float = 0.15, rho: float = 1e-3) -> torch.Tensor:
    B, N, _ = Rhat.shape
    dtype = Rhat.dtype
    I = cplx_eye(N, Rhat.device, dtype=dtype)[None].expand(B, -1, -1)
    Rl = hermitize(Rhat + rho * I)
    v = solve(Rl, a_nom)

    A = A_j
    AH_A = A.conj().transpose(-1, -2) @ A
    ridge = 1e-3 * torch.eye(3, device=Rhat.device, dtype=dtype)[None].expand(B, -1, -1)
    inv_AH_A = torch.linalg.inv(AH_A + ridge)
    Pperp = I - A @ inv_AH_A @ A.conj().transpose(-1, -2)

    g = (Pperp @ v.unsqueeze(-1)).squeeze(-1)
    g_unit = g / torch.linalg.norm(g, dim=-1, keepdim=True).clamp_min(1e-12)

    a_tilde = a_nom - eps * g_unit
    a_tilde = a_tilde / torch.linalg.norm(a_tilde, dim=-1, keepdim=True).clamp_min(1e-12)

    C = torch.cat([a_tilde.unsqueeze(-1), A], dim=-1)
    f = torch.zeros(B, 4, device=Rhat.device, dtype=dtype)
    f[:, 0] = 1.0 + 0.0j
    return lcmv_weight(Rl, C, f)


# =========================================================
# Metrics
# =========================================================
def sinr_out_db(w, a_true, Rin_true, sigma_s2) -> torch.Tensor:
    num = sigma_s2 * abs2((torch.conj(w) * a_true).sum(dim=-1))
    den = quad_form(w, Rin_true).clamp_min(1e-12)
    sinr = (num / den).clamp_min(1e-12)
    return 10.0 * torch.log10(sinr)


def catastrophic_rate(sinr_db: np.ndarray, thr_db: float = -5.0) -> float:
    s = np.asarray(sinr_db).reshape(-1)
    return float(100.0 * np.mean(s < thr_db))


# =========================================================
# Training (maximize mean SINR)
# =========================================================
def train_model(model: nn.Module, cfg: SimCfg, device,
                epochs: int, steps_per_epoch: int, batch_size: int,
                L_choices: Tuple[int, ...], snr_range: Tuple[float, float],
                lr: float = 3e-4) -> Dict[str, List[float]]:
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    hist = {"train": [], "val": []}

    def val_step(num_batches: int = 20) -> float:
        model.eval()
        vals = []
        with torch.no_grad():
            for _ in range(num_batches):
                L = random.choice(L_choices)
                snr = snr_range[0] + (snr_range[1] - snr_range[0]) * torch.rand(batch_size, device=device)
                batch = gen_scene_batch(cfg, batch_size, L, snr, device)
                out = model(batch["Rhat"])
                w = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out["tau"], out["rho"], out["lam_diag"])
                sinr = sinr_out_db(w, batch["a_true"], batch["Rin_true"], batch["sigma_s2"])
                vals.append((-sinr.mean()).item())
        model.train()
        return float(np.mean(vals))

    for ep in range(1, epochs + 1):
        losses = []
        for _ in range(steps_per_epoch):
            L = random.choice(L_choices)
            snr = snr_range[0] + (snr_range[1] - snr_range[0]) * torch.rand(batch_size, device=device)
            batch = gen_scene_batch(cfg, batch_size, L, snr, device)

            out = model(batch["Rhat"])
            w = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out["tau"], out["rho"], out["lam_diag"])
            sinr = sinr_out_db(w, batch["a_true"], batch["Rin_true"], batch["sigma_s2"])
            loss_main = -sinr.mean()

            reg = 1e-4 * (out["rho"] ** 2).mean() + 1e-4 * (out["tau"] ** 2).mean()
            reg = reg + 1e-5 * (safe_log(out["lam_diag"]) ** 2).mean()
            loss = loss_main + reg

            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            losses.append(loss_main.item())

        v = val_step()
        hist["train"].append(float(np.mean(losses)))
        hist["val"].append(v)
        print(f"Epoch {ep:03d}/{epochs} | train(-mean SINR dB)={hist['train'][-1]:.3f} | val={v:.3f}")

    return hist


# =========================================================
# Evaluation
# =========================================================
@torch.no_grad()
def eval_methods_once(cfg: SimCfg, device, snr_db: float, L: int, mc: int,
                      model_dict: Dict[str, nn.Module],
                      dl_rho_fixed: float = 0.1) -> Dict[str, np.ndarray]:
    snr_t = torch.full((mc,), float(snr_db), device=device)
    batch = gen_scene_batch(cfg, mc, L, snr_t, device)

    res = {}

    # Oracle optimal: true Rin + nominal a
    w_opt = mvdr_weight(batch["Rin_true"], batch["a_nom"])
    res["Optimal SINR"] = sinr_out_db(w_opt, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()

    # Baselines
    w_smi = mvdr_weight(batch["Rhat"], batch["a_nom"])
    res["SMI MVDR"] = sinr_out_db(w_smi, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()

    w_lsmi = lsmi_weight(batch["Rhat"], batch["a_nom"], beta=0.1)
    res["LSMI"] = sinr_out_db(w_lsmi, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()

    w_rcb = rcb_weight(batch["Rhat"], batch["a_nom"], eps=0.15)
    res["RCB"] = sinr_out_db(w_rcb, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()

    w_sub = subspace_mvdr_weight(batch["Rhat"], batch["a_nom"], K=3)
    res["Subspace MVDR"] = sinr_out_db(w_sub, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()

    w_shr = shrinkage_mvdr_weight(batch["Rhat"], batch["a_nom"], alpha=0.1)
    res["Shrinkage-MVDR"] = sinr_out_db(w_shr, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()

    w_rvo = rvo_lcmv_weight(batch["Rhat"], batch["a_nom"], batch["A_j"], eps=0.15, rho=1e-3)
    res["RVO-LCMV"] = sinr_out_db(w_rvo, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()

    w_dl = dl_mvdr_weight(batch["Rhat"], batch["a_nom"], rho=dl_rho_fixed)
    res[f"DL-MVDR(rho={dl_rho_fixed})"] = sinr_out_db(w_dl, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()

    # Proposed + ablations
    for name, mdl in model_dict.items():
        mdl.eval()
        out = mdl(batch["Rhat"])
        w = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out["tau"], out["rho"], out["lam_diag"])
        res[name] = sinr_out_db(w, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()

    return res


# =========================================================
# Plotting
# =========================================================
def plot_sinr_vs_snr_curves(curves: Dict[str, List[float]], snr_list: List[float],
                            title: str, out_base: str):
    set_pub_style()
    plt.figure(figsize=(6.8, 4.4))  # more journal-ish (fits 1.5x column nicely)

    for name, y_list in curves.items():
        y = np.asarray(y_list, dtype=np.float64)

        if name == "Proposed TM-DRO":
            plt.plot(snr_list, y, label=name, linewidth=2.6, marker="o")
        elif name == "Optimal SINR":
            plt.plot(snr_list, y, label=name, linewidth=2.3, linestyle="-")
        else:
            # Use slight variety: marker every other point to improve grayscale readability
            plt.plot(snr_list, y, label=name, linewidth=1.9)

    plt.xlabel("SNR (dB)")
    plt.ylabel("Output SINR (dB)")
    ax = plt.gca()
    apply_axis_style(ax)
    legend_outside_bottom(ax, max_cols=4)
    savefig_dual(out_base)
    plt.close()


def plot_catastrophic_vs_snr(cat_dict: Dict[str, List[float]], snr_list: List[float],
                             title: str, out_base: str):
    set_pub_style()
    plt.figure(figsize=(6.8, 4.4))

    for name, y in cat_dict.items():
        if name == "Proposed TM-DRO":
            plt.plot(snr_list, y, label=name, linewidth=2.6, marker="o")
        elif name == "Optimal SINR":
            plt.plot(snr_list, y, label=name, linewidth=2.3)
        else:
            plt.plot(snr_list, y, label=name, linewidth=1.9)

    plt.xlabel("SNR (dB)")
    plt.ylabel("Catastrophic rate (%)")
    ax = plt.gca()
    apply_axis_style(ax)
    legend_outside_bottom(ax, max_cols=4)
    savefig_dual(out_base)
    plt.close()


def plot_cov_heatmaps(R_list: List[torch.Tensor], titles: List[str], out_base: str,
                      vmin_db=-60, vmax_db=10):
    set_pub_style()
    K = len(R_list)
    fig, axes = plt.subplots(1, K, figsize=(4.6 * K, 4.0), constrained_layout=True)
    if K == 1:
        axes = [axes]

    im = None
    for ax, R, tt in zip(axes, R_list, titles):
        Rn = R.detach().cpu().numpy()
        mag_db = 20.0 * np.log10(np.maximum(np.abs(Rn), 1e-12))
        im = ax.imshow(mag_db, aspect="equal", vmin=vmin_db, vmax=vmax_db)
        ax.set_xlabel("Sensor index")
        ax.set_ylabel("Sensor index")
        ax.set_title(tt)
        # heatmap axes: grid not needed (would clutter)
        ax.tick_params(which="both", direction="out")

    cbar = fig.colorbar(im, ax=axes, shrink=0.90)
    cbar.set_label(r"$20\log_{10}(|R_{ij}|)$ (dB)")

    plt.savefig(out_base + ".pdf")
    plt.savefig(out_base + ".png", dpi=450)
    plt.close(fig)


def plot_eigenspectra(R_list: List[torch.Tensor], labels: List[str], out_base: str,
                      use_log=True, normalize_trace=True):
    set_pub_style()
    plt.figure(figsize=(6.8, 4.4))

    for R, lb in zip(R_list, labels):
        Rb = hermitize(R)
        evals = torch.linalg.eigvalsh(Rb).real
        evals = torch.flip(evals, dims=[-1])
        if normalize_trace:
            evals = evals / evals.sum().clamp_min(1e-12)
        y = evals.clamp_min(1e-12)
        if use_log:
            y = torch.log(y)
        y = y.detach().cpu().numpy()
        x = np.arange(1, len(y) + 1)
        plt.plot(x, y, marker="o", label=lb, linewidth=2.1)

    plt.xlabel("Eigenvalue index (descending)")
    if use_log and normalize_trace:
        plt.ylabel(r"$\log(\lambda_i)$ (trace-normalized)")
    elif use_log:
        plt.ylabel(r"$\log(\lambda_i)$")
    else:
        plt.ylabel(r"$\lambda_i$")

    ax = plt.gca()
    apply_axis_style(ax)
    legend_outside_bottom(ax, max_cols=3)
    savefig_dual(out_base)
    plt.close()


@torch.no_grad()
def plot_beampattern_annotated(cfg: SimCfg, device,
                               weights_dict: Dict[str, torch.Tensor],
                               out_base: str):
    """
    Beampattern (normalized), annotate SOI & interferers using vertical dashed lines.
    """
    set_pub_style()
    thetas = torch.linspace(-90.0, 90.0, 721, device=device)
    A = steering_ula(cfg.N, cfg.d_over_lambda, thetas, device=device)

    plt.figure(figsize=(6.8, 4.4))
    for name, w in weights_dict.items():
        resp = torch.abs(A @ torch.conj(w))
        resp_db = 20.0 * torch.log10((resp / resp.max()).clamp_min(1e-8))
        if name == "Proposed TM-DRO":
            plt.plot(thetas.cpu().numpy(), resp_db.cpu().numpy(), label=name, linewidth=2.6)
        elif name == "Optimal SINR":
            plt.plot(thetas.cpu().numpy(), resp_db.cpu().numpy(), label=name, linewidth=2.3)
        else:
            plt.plot(thetas.cpu().numpy(), resp_db.cpu().numpy(), label=name, linewidth=1.9)

    # key angles
    plt.axvline(cfg.theta_s_nom_deg, linestyle="--", linewidth=1.8)
    for th in cfg.theta_js_deg:
        plt.axvline(th, linestyle="--", linewidth=1.8)

    plt.ylim([-80, 5])
    plt.xlabel("Angle (deg)")
    plt.ylabel("Normalized beampattern (dB)")
    ax = plt.gca()
    apply_axis_style(ax)
    legend_outside_bottom(ax, max_cols=3)
    savefig_dual(out_base)
    plt.close()


def plot_snapshot_sensitivity(curves: Dict[str, Dict[float, List[float]]],
                              L_list: List[int], snr_list: List[float],
                              title: str, out_base: str):
    set_pub_style()
    plt.figure(figsize=(6.9, 4.5))

    for m in curves.keys():
        for snr in snr_list:
            y = curves[m][snr]
            lbl = f"{m} @ SNR={snr} dB"
            if m == "Proposed TM-DRO":
                plt.plot(L_list, y, label=lbl, linewidth=2.5, marker="o")
            else:
                plt.plot(L_list, y, label=lbl, linewidth=1.9)

    plt.xscale("log")
    plt.xlabel("Snapshots $L$ (log scale)")
    plt.ylabel("Output SINR (dB)")
    ax = plt.gca()
    apply_axis_style(ax)
    legend_outside_bottom(ax, max_cols=3)
    savefig_dual(out_base)
    plt.close()


def plot_heatmap(Z: np.ndarray, x_ticks: List[float], y_ticks: List[float],
                 title: str, xlabel: str, ylabel: str, cbar_label: str,
                 out_base: str):
    set_pub_style()
    plt.figure(figsize=(6.9, 4.6))
    im = plt.imshow(Z, aspect="auto", origin="lower")
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.xticks(np.arange(len(x_ticks)), [str(x) for x in x_ticks])
    plt.yticks(np.arange(len(y_ticks)), [str(y) for y in y_ticks])
    cbar = plt.colorbar(im)
    cbar.set_label(cbar_label)
    plt.savefig(out_base + ".pdf")
    plt.savefig(out_base + ".png", dpi=450)
    plt.close()


# =========================================================
# PCA (SVD) + plotting + saving embeddings
# =========================================================
def pca_2d(X: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    PCA to 2D using SVD (no sklearn dependency).
    Returns:
      Z: [M,2] PCA coords
      mean: [D]
      V2: [2,D] principal axes
    """
    X = np.asarray(X, dtype=np.float64)
    mean = X.mean(axis=0, keepdims=True)
    Xc = X - mean
    _, _, Vt = np.linalg.svd(Xc, full_matrices=False)
    V2 = Vt[:2, :]
    Z = Xc @ V2.T
    return Z, mean.squeeze(0), V2


def plot_embedding_pca(emb: np.ndarray, labels: List[str], title: str, out_base: str):
    set_pub_style()
    Z, _, _ = pca_2d(emb)

    plt.figure(figsize=(6.8, 4.4))
    uniq = sorted(list(set(labels)))
    for lb in uniq:
        idx = [i for i, x in enumerate(labels) if x == lb]
        plt.scatter(Z[idx, 0], Z[idx, 1], s=26, label=lb, alpha=0.85)

    plt.xlabel("PCA-1")
    plt.ylabel("PCA-2")
    ax = plt.gca()
    apply_axis_style(ax)
    legend_outside_bottom(ax, max_cols=3)
    savefig_dual(out_base)
    plt.close()

    return Z


# =========================================================
# Figure pipelines
# =========================================================
@torch.no_grad()
def make_cov_and_spectrum_figs(cfg: SimCfg, device, out_dir: str, L: int, snr_db: float):
    # Case A: noise dominated
    bA = gen_scene_custom(cfg, 1, L, snr_db=-30.0, device=device, inr_db=-30.0, mismatch_std_deg=0.0)
    # Case B: target + noise
    bB = gen_scene_custom(cfg, 1, L, snr_db=snr_db, device=device, inr_db=-30.0, mismatch_std_deg=0.0)
    # Case C: target + interference + mismatch
    bC = gen_scene_custom(cfg, 1, L, snr_db=snr_db, device=device,
                          inr_db=cfg.INR_dB, mismatch_std_deg=cfg.mismatch_std_deg)

    R_A, R_B, R_C = bA["Rhat"][0], bB["Rhat"][0], bC["Rhat"][0]

    plot_cov_heatmaps(
        [R_A, R_B, R_C],
        [f"Case A: noise-dom (L={L})",
         f"Case B: target+noise (SNR={snr_db} dB, L={L})",
         f"Case C: +interf+mismatch (INR={cfg.INR_dB} dB, L={L})"],
        os.path.join(out_dir, "fig_cov_heatmaps_3cases")
    )

    plot_eigenspectra(
        [R_A, R_B, R_C],
        ["Case A: noise-dom", "Case B: target+noise", "Case C: +interf+mismatch"],
        os.path.join(out_dir, "fig_eigspectra_3cases"),
        use_log=True, normalize_trace=True
    )

    # Export spectra values to CSV
    rows = []
    for tag, R in [("A_noise", R_A), ("B_target", R_B), ("C_interf_mis", R_C)]:
        evals = torch.linalg.eigvalsh(hermitize(R)).real
        evals = torch.flip(evals, dims=[-1])
        evals = (evals / evals.sum().clamp_min(1e-12)).detach().cpu().numpy()
        for i, v in enumerate(evals, start=1):
            rows.append([tag, i, float(v)])
    write_csv(os.path.join(out_dir, "data_eigspectra_3cases.csv"),
              ["case", "eig_idx", "eig_trace_norm"], rows)


@torch.no_grad()
def make_sinr_vs_snr_figs(cfg: SimCfg, device, out_dir: str,
                          models_for_plot: Dict[str, nn.Module],
                          snr_list: List[float],
                          L: int, mc_runs: int,
                          dl_rho_fixed: float = 0.1,
                          fig_name: str = "fig_sinr_vs_snr",
                          export_prefix: str = "data_sinr_vs_snr"):
    curves_mean = {k: [] for k in (["Optimal SINR"] + list(models_for_plot.keys()) +
                                   [f"DL-MVDR(rho={dl_rho_fixed})",
                                    "SMI MVDR", "LSMI", "RCB", "Subspace MVDR", "Shrinkage-MVDR", "RVO-LCMV"])}

    cat_curves = {k: [] for k in curves_mean.keys()}

    for snr in snr_list:
        res = eval_methods_once(cfg, device, snr, L, mc_runs, models_for_plot, dl_rho_fixed=dl_rho_fixed)
        for k in curves_mean.keys():
            if k in res:
                curves_mean[k].append(float(np.mean(res[k])))
                cat_curves[k].append(catastrophic_rate(res[k], thr_db=-5.0))

    # Plot
    plot_sinr_vs_snr_curves(curves_mean, snr_list,
                            title=f"Output SINR vs SNR (snapshots={L})",
                            out_base=os.path.join(out_dir, f"{fig_name}_L{L}"))

    plot_catastrophic_vs_snr(cat_curves, snr_list,
                             title=f"Catastrophic rate vs SNR (snapshots={L}, thr=-5 dB)",
                             out_base=os.path.join(out_dir, f"fig_cat_rate_L{L}"))

    # Export curves
    header = ["snr_db"] + list(curves_mean.keys())
    rows = []
    for i, snr in enumerate(snr_list):
        row = [snr]
        for k in curves_mean.keys():
            row.append(curves_mean[k][i])
        rows.append(row)
    write_csv(os.path.join(out_dir, f"{export_prefix}_L{L}.csv"), header, rows)

    header2 = ["snr_db"] + list(cat_curves.keys())
    rows2 = []
    for i, snr in enumerate(snr_list):
        row = [snr]
        for k in cat_curves.keys():
            row.append(cat_curves[k][i])
        rows2.append(row)
    write_csv(os.path.join(out_dir, f"data_cat_rate_L{L}.csv"), header2, rows2)

    return curves_mean, cat_curves


@torch.no_grad()
def make_ablation_fig(cfg: SimCfg, device, out_dir: str,
                      ablation_models: Dict[str, nn.Module],
                      snr_list: List[float], L: int, mc_runs: int):
    curves = {k: [] for k in ["Optimal SINR"] + list(ablation_models.keys()) + ["SMI MVDR"]}
    for snr in snr_list:
        res = eval_methods_once(cfg, device, snr, L, mc_runs, ablation_models, dl_rho_fixed=0.1)
        for k in curves.keys():
            if k in res:
                curves[k].append(float(np.mean(res[k])))

    plot_sinr_vs_snr_curves(curves, snr_list,
                            title=f"Ablation: SINR vs SNR (snapshots={L})",
                            out_base=os.path.join(out_dir, f"fig_ablation_L{L}"))

    header = ["snr_db"] + list(curves.keys())
    rows = []
    for i, snr in enumerate(snr_list):
        rows.append([snr] + [curves[k][i] for k in curves.keys()])
    write_csv(os.path.join(out_dir, f"data_ablation_L{L}.csv"), header, rows)


@torch.no_grad()
def make_robustness_phase_diagram(cfg: SimCfg, device, out_dir: str,
                                  proposed_model: nn.Module,
                                  snr_list: List[float],
                                  mismatch_list: List[float],
                                  L: int, mc_runs: int):
    """
    Heatmaps:
      - ΔSINR(Proposed - SMI) in dB
      - ΔCatRate(SMI - Proposed) in percentage points (positive is better)
    """
    Z_sinr = np.zeros((len(mismatch_list), len(snr_list)), dtype=np.float64)
    Z_cat = np.zeros_like(Z_sinr)

    for i, mis in enumerate(mismatch_list):
        for j, snr in enumerate(snr_list):
            batch = gen_scene_custom(cfg, B=mc_runs, L=L, snr_db=snr, device=device,
                                     inr_db=cfg.INR_dB, mismatch_std_deg=mis)

            # SMI
            w_smi = mvdr_weight(batch["Rhat"], batch["a_nom"])
            sinr_smi = sinr_out_db(w_smi, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()
            cat_smi = catastrophic_rate(sinr_smi, thr_db=-5.0)

            # Proposed
            out = proposed_model(batch["Rhat"])
            w_p = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out["tau"], out["rho"], out["lam_diag"])
            sinr_p = sinr_out_db(w_p, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).cpu().numpy()
            cat_p = catastrophic_rate(sinr_p, thr_db=-5.0)

            Z_sinr[i, j] = float(np.mean(sinr_p) - np.mean(sinr_smi))
            Z_cat[i, j] = float(cat_smi - cat_p)

    plot_heatmap(Z_sinr, snr_list, mismatch_list,
                 title=f"Robustness map: ΔSINR(Proposed−SMI), L={L}",
                 xlabel="SNR (dB)", ylabel="Mismatch std (deg)",
                 cbar_label="ΔSINR (dB)",
                 out_base=os.path.join(out_dir, "fig_phase_delta_sinr"))

    plot_heatmap(Z_cat, snr_list, mismatch_list,
                 title=f"Robustness map: ΔCatRate(SMI−Proposed), L={L}, thr=-5 dB",
                 xlabel="SNR (dB)", ylabel="Mismatch std (deg)",
                 cbar_label="ΔCatRate (percentage points)",
                 out_base=os.path.join(out_dir, "fig_phase_delta_catrate"))

    # Export heatmaps
    rows_sinr = []
    for i, mis in enumerate(mismatch_list):
        for j, snr in enumerate(snr_list):
            rows_sinr.append([mis, snr, float(Z_sinr[i, j])])
    write_csv(os.path.join(out_dir, "data_phase_delta_sinr.csv"),
              ["mismatch_deg", "snr_db", "delta_sinr_db"], rows_sinr)

    rows_cat = []
    for i, mis in enumerate(mismatch_list):
        for j, snr in enumerate(snr_list):
            rows_cat.append([mis, snr, float(Z_cat[i, j])])
    write_csv(os.path.join(out_dir, "data_phase_delta_catrate.csv"),
              ["mismatch_deg", "snr_db", "delta_catrate_pp"], rows_cat)


@torch.no_grad()
def make_snapshot_sensitivity(cfg: SimCfg, device, out_dir: str,
                              proposed_model: nn.Module,
                              L_list: List[int],
                              snr_list: List[float],
                              mc_runs: int):
    """
    Compare Proposed vs SMI across L.
    """
    curves = {"Proposed TM-DRO": {snr: [] for snr in snr_list},
              "SMI MVDR": {snr: [] for snr in snr_list}}

    for L in L_list:
        for snr in snr_list:
            batch = gen_scene_custom(cfg, B=mc_runs, L=L, snr_db=snr, device=device,
                                     inr_db=cfg.INR_dB, mismatch_std_deg=cfg.mismatch_std_deg)
            # SMI
            w_smi = mvdr_weight(batch["Rhat"], batch["a_nom"])
            sinr_smi = sinr_out_db(w_smi, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).mean().item()

            # Proposed
            out = proposed_model(batch["Rhat"])
            w_p = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out["tau"], out["rho"], out["lam_diag"])
            sinr_p = sinr_out_db(w_p, batch["a_true"], batch["Rin_true"], batch["sigma_s2"]).mean().item()

            curves["Proposed TM-DRO"][snr].append(float(sinr_p))
            curves["SMI MVDR"][snr].append(float(sinr_smi))

    plot_snapshot_sensitivity(curves, L_list, snr_list,
                              title="Snapshot sensitivity: SINR vs L",
                              out_base=os.path.join(out_dir, "fig_sinr_vs_L"))

    # Export
    header = ["L", "snr_db", "method", "mean_sinr_db"]
    rows = []
    for L_idx, L in enumerate(L_list):
        for snr in snr_list:
            rows.append([L, snr, "Proposed TM-DRO", curves["Proposed TM-DRO"][snr][L_idx]])
            rows.append([L, snr, "SMI MVDR", curves["SMI MVDR"][snr][L_idx]])
    write_csv(os.path.join(out_dir, "data_sinr_vs_L.csv"), header, rows)


@torch.no_grad()
def make_embedding_pca_fig(cfg: SimCfg, device, out_dir: str,
                           model: nn.Module,
                           L: int, snr_db: float,
                           n_per_class: int = 60):
    """
    Classes:
      - Noise-dom
      - Target+Noise
      - Strong Interf
      - Mismatch Heavy
    """
    model.eval()
    classes = [
        ("Noise-dom", dict(snr_db=-30.0, inr_db=-30.0, mismatch=0.0)),
        ("Target+Noise", dict(snr_db=snr_db, inr_db=-30.0, mismatch=0.0)),
        ("Strong Interf", dict(snr_db=snr_db, inr_db=cfg.INR_dB, mismatch=0.0)),
        ("Mismatch Heavy", dict(snr_db=snr_db, inr_db=cfg.INR_dB, mismatch=max(4.0, cfg.mismatch_std_deg * 2))),
    ]

    embs = []
    lbs = []
    for cname, params in classes:
        batch = gen_scene_custom(cfg, B=n_per_class, L=L, snr_db=params["snr_db"], device=device,
                                 inr_db=params["inr_db"], mismatch_std_deg=params["mismatch"])
        out = model(batch["Rhat"])
        g = out["embed"].detach().cpu().numpy()
        embs.append(g)
        lbs += [cname] * g.shape[0]

    emb = np.concatenate(embs, axis=0)

    # Export raw embeddings
    rows = []
    for i in range(emb.shape[0]):
        rows.append([lbs[i]] + [float(x) for x in emb[i].tolist()])
    write_csv(os.path.join(out_dir, "data_embeddings.csv"),
              ["label"] + [f"dim{i+1}" for i in range(emb.shape[1])], rows)

    # PCA and plot
    Z = plot_embedding_pca(emb, lbs, title="Scene embeddings (PCA) from eigen-spectrum tokens",
                           out_base=os.path.join(out_dir, "fig_embedding_pca"))

    # Export PCA coords
    rows2 = []
    for i in range(Z.shape[0]):
        rows2.append([lbs[i], float(Z[i, 0]), float(Z[i, 1])])
    write_csv(os.path.join(out_dir, "data_embeddings_pca2d.csv"),
              ["label", "pca1", "pca2"], rows2)


# =========================================================
# Paper tables
# =========================================================
@torch.no_grad()
def make_paper_tables(cfg: SimCfg, device, out_dir: str,
                      models_main: Dict[str, nn.Module],
                      L_list: List[int],
                      snr_db: float = 10.0,
                      mc_runs: int = 600,
                      dl_rho_fixed: float = 0.1,
                      outage_thr_db: float = -5.0):
    """
    Table 1: mean/median SINR at SNR=10 dB for L in L_list
    Table 2: (loss gap to optimal) + (outage rate) combined
    """
    methods = ["Optimal SINR"] + list(models_main.keys()) + [
        "Shrinkage-MVDR", "LSMI", "RCB", "RVO-LCMV",
        f"DL-MVDR(rho={dl_rho_fixed})", "SMI MVDR", "Subspace MVDR"
    ]

    stats = {L: {} for L in L_list}
    for L in L_list:
        res = eval_methods_once(cfg, device, snr_db, L, mc_runs, models_main, dl_rho_fixed=dl_rho_fixed)
        for m in methods:
            if m in res:
                x = np.asarray(res[m]).reshape(-1)
                stats[L][m] = {
                    "mean": float(np.mean(x)),
                    "median": float(np.median(x)),
                    "outage": float(np.mean(x < outage_thr_db) * 100.0)
                }

    # ---------- Table 1 (mean/median) ----------
    rows_csv = []
    for m in methods:
        row = [m]
        for L in L_list:
            row += [f"{stats[L][m]['mean']:.2f}", f"{stats[L][m]['median']:.2f}"]
        rows_csv.append(row)

    header = ["Method"]
    for L in L_list:
        header += [f"Mean@L{L}", f"Median@L{L}"]
    write_csv(os.path.join(out_dir, "table_sinr_mean_median.csv"), header, rows_csv)

    # LaTeX
    header_lines = []
    if len(L_list) == 2:
        L1, L2 = L_list
        header_lines.append(f"& \\multicolumn{{2}}{{c}}{{Snapshots = {L1}}} & \\multicolumn{{2}}{{c}}{{Snapshots = {L2}}} \\\\")
        header_lines.append("\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}")
        header_lines.append("Method & Mean SINR & Median SINR & Mean SINR & Median SINR \\\\")
        colspec = "lcccc"
        body_lines = []
        for m in methods:
            body_lines.append(
                f"{m} & {stats[L1][m]['mean']:.2f} & {stats[L1][m]['median']:.2f} & {stats[L2][m]['mean']:.2f} & {stats[L2][m]['median']:.2f} \\\\"
            )
        write_tex_table(
            os.path.join(out_dir, "table_sinr_mean_median.tex"),
            caption=f"Mean and median output SINR (dB) at $\\mathrm{{SNR}}={snr_db}$~dB under steering mismatch.",
            label="tab:sinr_mean_median",
            colspec=colspec,
            header_lines=header_lines,
            body_lines=body_lines,
            notes=f"Averaged over {mc_runs} Monte Carlo trials. "
                  f"$\\theta_s^{{\\mathrm{{true}}}}=\\theta_s^{{\\mathrm{{nom}}}}+\\mathcal{{N}}(0,\\sigma_\\theta^2)$ "
                  f"with $\\sigma_\\theta={cfg.mismatch_std_deg}^\\circ$."
        )
    else:
        colspec = "l" + "c" * (2 * len(L_list))
        header_lines.append("Method " + " & ".join([f"& Mean@{L} & Median@{L}" for L in L_list]) + " \\\\")
        body_lines = []
        for m in methods:
            vals = []
            for L in L_list:
                vals += [f"{stats[L][m]['mean']:.2f}", f"{stats[L][m]['median']:.2f}"]
            body_lines.append(m + " & " + " & ".join(vals) + " \\\\")
        write_tex_table(
            os.path.join(out_dir, "table_sinr_mean_median.tex"),
            caption=f"Mean and median output SINR (dB) at $\\mathrm{{SNR}}={snr_db}$~dB under steering mismatch.",
            label="tab:sinr_mean_median",
            colspec=colspec,
            header_lines=header_lines,
            body_lines=body_lines
        )

    # ---------- Table 2: loss gap + outage ----------
    rows2 = []
    for m in methods:
        row = [m]
        for L in L_list:
            opt_mean = stats[L]["Optimal SINR"]["mean"]
            gap = opt_mean - stats[L][m]["mean"]
            outage = stats[L][m]["outage"]
            row += [f"{gap:.2f}", f"{outage:.2f}"]
        rows2.append(row)

    header2 = ["Method"]
    for L in L_list:
        header2 += [f"LossGap@L{L}", f"Outage%(<{outage_thr_db}dB)@L{L}"]
    write_csv(os.path.join(out_dir, "table_loss_outage.csv"), header2, rows2)

    if len(L_list) == 2:
        L1, L2 = L_list
        header_lines2 = []
        header_lines2.append(f"& \\multicolumn{{2}}{{c}}{{Snapshots = {L1}}} & \\multicolumn{{2}}{{c}}{{Snapshots = {L2}}} \\\\")
        header_lines2.append("\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}")
        header_lines2.append(f"Method & Loss gap & Outage (\\%) & Loss gap & Outage (\\%) \\\\")
        colspec2 = "lcccc"
        body2 = []
        for m in methods:
            opt1 = stats[L1]["Optimal SINR"]["mean"]
            opt2 = stats[L2]["Optimal SINR"]["mean"]
            gap1 = opt1 - stats[L1][m]["mean"]
            gap2 = opt2 - stats[L2][m]["mean"]
            out1 = stats[L1][m]["outage"]
            out2 = stats[L2][m]["outage"]
            body2.append(f"{m} & {gap1:.2f} & {out1:.2f} & {gap2:.2f} & {out2:.2f} \\\\")
        write_tex_table(
            os.path.join(out_dir, "table_loss_outage.tex"),
            caption=f"Combined robustness indicators at $\\mathrm{{SNR}}={snr_db}$~dB: "
                    f"loss gap to optimal mean SINR (dB) and outage rate (\\%) below {outage_thr_db}~dB.",
            label="tab:loss_outage",
            colspec=colspec2,
            header_lines=header_lines2,
            body_lines=body2,
            notes=f"Outage threshold: {outage_thr_db} dB. Averaged over {mc_runs} Monte Carlo trials."
        )


# =========================================================
# Main
# =========================================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--out_dir", type=str, default="./outputs_allfigs_paper")

    # training
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--steps_per_epoch", type=int, default=180)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--lr", type=float, default=3e-4)

    # model
    parser.add_argument("--d_model", type=int, default=96)
    parser.add_argument("--n_layers", type=int, default=3)

    # sim
    parser.add_argument("--N", type=int, default=10)
    parser.add_argument("--mismatch_std_deg", type=float, default=2.0)
    parser.add_argument("--INR_dB", type=float, default=20.0)
    parser.add_argument("--theta_j1", type=float, default=20.0)
    parser.add_argument("--theta_j2", type=float, default=50.0)
    parser.add_argument("--theta_j3", type=float, default=65.0)

    # eval
    parser.add_argument("--mc_runs", type=int, default=300)
    parser.add_argument("--fast", type=int, default=0, help="1=run faster (less training/eval)")

    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    set_seed(args.seed)
    set_pub_style()

    device = torch.device(args.device)

    cfg = SimCfg(
        N=args.N,
        mismatch_std_deg=args.mismatch_std_deg,
        INR_dB=args.INR_dB,
        theta_js_deg=(args.theta_j1, args.theta_j2, args.theta_j3),
    )

    # ---- Create models ----
    model_full = EigenTokenSSM(N=cfg.N, d_model=args.d_model, n_layers=args.n_layers, dropout=0.05).to(device)
    model_mlp_reduced = EigenMLPParam(N=cfg.N, hidden=128, dropout=0.05).to(device)
    model_no_mixing = EigenTokenMLP(N=cfg.N, d_model=args.d_model, hidden=192, dropout=0.05).to(device)
    model_no_lam = EigenTokenSSM_NoLam(N=cfg.N, d_model=args.d_model, n_layers=args.n_layers, dropout=0.05).to(device)
    model_only_rho = OnlyRhoModel(N=cfg.N, hidden=128, dropout=0.05).to(device)

    # ---- Training schedule ----
    if args.fast == 1:
        epochs = max(4, args.epochs // 3)
        steps_per_epoch = max(60, args.steps_per_epoch // 3)
        mc_runs = max(120, args.mc_runs // 2)
        mc_table = max(240, args.mc_runs)
        n_embed = 40
    else:
        epochs = args.epochs
        steps_per_epoch = args.steps_per_epoch
        mc_runs = args.mc_runs
        mc_table = 600
        n_embed = 60

    L_choices = (16, 32, 48)
    snr_range = (-15.0, 25.0)

    # ---- Train models ----
    print("\n=== Training: Proposed (Full) ===")
    train_model(model_full, cfg, device, epochs, steps_per_epoch, args.batch_size, L_choices, snr_range, lr=args.lr)

    print("\n=== Training: Reduced (learn tau,rho) ===")
    train_model(model_mlp_reduced, cfg, device, max(3, epochs), max(60, steps_per_epoch ),
                args.batch_size, L_choices, snr_range, lr=args.lr)

    print("\n=== Training: Ablation (No token mixing) ===")
    train_model(model_no_mixing, cfg, device, max(3, epochs ), max(60, steps_per_epoch ),
                args.batch_size, L_choices, snr_range, lr=args.lr)

    print("\n=== Training: Ablation (No lam learning) ===")
    train_model(model_no_lam, cfg, device, max(3, epochs ), max(60, steps_per_epoch ),
                args.batch_size, L_choices, snr_range, lr=args.lr)

    print("\n=== Training: Ablation (Only rho) ===")
    train_model(model_only_rho, cfg, device, max(3, epochs ), max(60, steps_per_epoch ),
                args.batch_size, L_choices, snr_range, lr=args.lr)

    # ---- Models for main plots ----
    models_main = {
        "Proposed TM-DRO": model_full,
        "Proposed TM-DRO (learn tau,rho)": model_mlp_reduced,
    }

    # ---- SNR lists / snapshot settings ----
    snr_list = list(range(-20, 31, 5))
    L_list_main = [100, 500]

    # ======================================================
    # FIGURES (ALL)
    # ======================================================

    make_sinr_vs_snr_figs(cfg, device, args.out_dir, models_main, snr_list, L=100, mc_runs=mc_runs,
                          fig_name="fig2a_sinr_vs_snr", export_prefix="data_sinr_vs_snr_fig2a")
    make_sinr_vs_snr_figs(cfg, device, args.out_dir, models_main, snr_list, L=500, mc_runs=mc_runs,
                          fig_name="fig2b_sinr_vs_snr", export_prefix="data_sinr_vs_snr_fig2b")

    # (3) Beampattern (fixed SNR)
    with torch.no_grad():
        batch = gen_scene_custom(cfg, B=1, L=500, snr_db=10.0, device=device,
                                 inr_db=cfg.INR_dB, mismatch_std_deg=cfg.mismatch_std_deg)
        w_opt = mvdr_weight(batch["Rin_true"], batch["a_nom"])[0]
        w_smi = mvdr_weight(batch["Rhat"], batch["a_nom"])[0]
        w_shr = shrinkage_mvdr_weight(batch["Rhat"], batch["a_nom"], alpha=0.1)[0]

        out_full = model_full(batch["Rhat"])
        w_prop = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out_full["tau"], out_full["rho"], out_full["lam_diag"])[0]

        out_red = model_mlp_reduced(batch["Rhat"])
        w_prop2 = robust_beamformer_from_params(batch["Rhat"], batch["bar_a"], out_red["tau"], out_red["rho"], out_red["lam_diag"])[0]

        weights_dict = {
            "Optimal SINR": w_opt,
            "Proposed TM-DRO": w_prop,
            "Proposed TM-DRO (learn tau,rho)": w_prop2,
            "SMI MVDR": w_smi,
            "Shrinkage-MVDR": w_shr,
        }
        plot_beampattern_annotated(cfg, device, weights_dict,
                                   out_base=os.path.join(args.out_dir, "fig2c_beampattern"))

    # (4)(5) Cov heatmaps + eigen-spectra
    make_cov_and_spectrum_figs(cfg, device, args.out_dir, L=500, snr_db=10.0)

    # (6) Ablation SINR vs SNR (L=100)
    ablation_models = {
        "Proposed TM-DRO": model_full,
        "Abl: No token mixing (MLP)": model_no_mixing,
        "Abl: No lam (lam=1)": model_no_lam,
        "Abl: Reduced (tau,rho only)": model_mlp_reduced,
        "Abl: Only rho": model_only_rho,
    }
    make_ablation_fig(cfg, device, args.out_dir, ablation_models, snr_list, L=100, mc_runs=mc_runs)

    # (7) Robustness phase diagrams (SNR × mismatch)
    mismatch_grid = [0.0, 1.0, 2.0, 3.0, 4.0, 6.0]
    snr_grid = [-10, -5, 0, 5, 10, 15, 20]
    make_robustness_phase_diagram(cfg, device, args.out_dir, model_full,
                                  snr_grid, mismatch_grid, L=100, mc_runs=max(120, mc_runs // 2))

    # (8) Snapshot sensitivity (SINR vs L)
    L_list = [16, 32, 64, 100, 200, 500]
    snr_for_L = [0.0, 10.0, 20.0]
    make_snapshot_sensitivity(cfg, device, args.out_dir,
                              proposed_model=model_full,
                              L_list=L_list, snr_list=snr_for_L,
                              mc_runs=max(120, mc_runs // 2))

    # (9) Token embedding PCA 2D
    make_embedding_pca_fig(cfg, device, args.out_dir, model_full, L=200, snr_db=10.0,
                           n_per_class=n_embed)

    # Paper tables
    make_paper_tables(cfg, device, args.out_dir,
                      models_main=models_main,
                      L_list=[100, 500],
                      snr_db=10.0,
                      mc_runs=mc_table)

    print(f"\nAll figures + tables saved to: {args.out_dir}\n"
          f"Tip: LaTeX 插图优先用 .pdf（矢量清晰），表直接 \\\\input{{...tex}} 即可。")


if __name__ == "__main__":
    main()
